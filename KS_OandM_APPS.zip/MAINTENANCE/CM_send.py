import gradio as gr
import shutil
import uuid
import datetime
import json
from pathlib import Path
import os
import socket
import re
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import mimetypes
import sys
# ===== SCHEDULER DEPENDENCIES =====
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import tempfile
from datetime import datetime as dt  # Avoid conflict with datetime module

# ======================
# CONFIGURATION (FIXED)
# ======================
def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

MYLOCALIP = get_local_ip()
CMLOGS_DB_FNAME = "cmlogs-db.json"
SECRETFILE = "secret.json"
INST_RECIPIENTS_FILE = "CMemails.txt"
ICSS_RECIPIENTS_FILE = "CM-ICSS-emails.txt"
SENDER_EMAIL = "fabio.matricardi@gmail.com"
ATTACHMENTS_DIR = "attachments"
os.makedirs(ATTACHMENTS_DIR, exist_ok=True)
VALID_STATUSES = ['sent', 'ongoing', 'completed']  # Centralized validation

# Load Gmail password securely
GMAIL_APP_PASSWORD = None
try:
    with open(SECRETFILE) as f:
        GMAIL_APP_PASSWORD = json.load(f)['secret_code']
except Exception as e:
    print(f"⚠️ Secret file error: {e}. Email functionality disabled.")

# Initialize database if missing
if not os.path.exists(CMLOGS_DB_FNAME):
    with open(CMLOGS_DB_FNAME, 'w') as f:
        json.dump([], f)
    print(f"✅ Created new log database: {CMLOGS_DB_FNAME}")

# ======================
# SCHEDULED REPORTS FOR CORRECTIVE MAINTENANCE
# ======================
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
import pytz
import logging
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment

# Configure scheduler logging
logging.basicConfig(level=logging.INFO)
scheduler_logger = logging.getLogger('apscheduler.executors.default')
scheduler_logger.setLevel(logging.INFO)

# ⏰ CONFIGURABLE SCHEDULE TIMES (Africa/Brazzaville = UTC+1)
# Edit these values to change report times without touching core logic
CM_REPORT_T1_HOUR = 7    # Morning report hour (07:40)
CM_REPORT_T1_MINUTE = 40 # Morning report minute
CM_REPORT_T2_HOUR = 18   # Evening report hour (18:40)
CM_REPORT_T2_MINUTE = 40 # Evening report minute

CM_TIMEZONE = pytz.timezone('Africa/Brazzaville')
SCHEDULED_REPORTS_LOG = "scheduled_cm_reports.log"





def send_scheduled_cm_report(report_type="automated"):
    """
    Send scheduled CM log report with Excel export
    report_type: Descriptive string for audit trail (e.g., "08:30 Daily Report")
    """
    try:
        timestamp = datetime.datetime.now(CM_TIMEZONE).strftime('%Y-%m-%d %H:%M:%S')
        print(f"\n⏰ SCHEDULED CM REPORT TRIGGERED [{timestamp}] - Type: {report_type}")
        
        # Generate Excel export
        excel_path, excel_msg = export_cm_logs_excel()
        if excel_path is None:
            raise Exception(f"Excel export failed: {excel_msg}")
        
        # Load database for summary statistics
        with open(CMLOGS_DB_FNAME, 'r', encoding='utf-8') as f:
            db = json.load(f)
        
        # Calculate status distribution
        status_counts = {'sent': 0, 'ongoing': 0, 'completed': 0}
        for entry in db:
            status = entry.get('status', 'sent').lower()
            if status in status_counts:
                status_counts[status] += 1
        
        # Prepare professional email body
        custom_note = (
            f"CORRECTIVE MAINTENANCE LOG SCHEDULED REPORT ({report_type})\n"
            f"Generated at: {timestamp} (Africa/Brazzaville Time)\n"
            f"Total Entries: {len(db)}\n"
            f"Status Distribution:\n"
            f"  • Sent: {status_counts['sent']}\n"
            f"  • Ongoing: {status_counts['ongoing']}\n"
            f"  • Completed: {status_counts['completed']}\n"
            f"IP ADDRESS: {MYLOCALIP}\n"
            f"⚠️ AUTOMATED REPORT - DO NOT REPLY\n"
            f"Workflow: sent → ongoing → completed (manually updated by technicians)"
        )
        
        # Get recipients from CMemails.txt
        recipients = []
        if not os.path.exists(INST_RECIPIENTS_FILE):
            raise Exception(f"Recipient file '{INST_RECIPIENTS_FILE}' not found")
        
        with open(INST_RECIPIENTS_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                email = line.strip()
                if email and not email.startswith('#') and '@' in email:
                    recipients.append(email)
        
        if not recipients:
            raise Exception("No valid recipient emails found in CMemails.txt")
        
        # Send email with Excel attachment
        status = send_email_with_exports(
            recipients=recipients,
            attachments_info=[(excel_path, "CM_LOGS_FULL_EXPORT.xlsx")],
            custom_note=custom_note
        )
        
        # Cleanup temporary file
        try:
            if excel_path and os.path.exists(excel_path):
                os.remove(excel_path)
        except Exception as e:
            print(f"⚠️ Cleanup warning for {excel_path}: {str(e)}")
        
        # Log success
        log_msg = f"✅ SCHEDULED CM REPORT SENT [{timestamp}] to {len(recipients)} recipients"
        print(log_msg)
        with open(SCHEDULED_REPORTS_LOG, "a", encoding="utf-8") as log:
            log.write(f"{timestamp} | SUCCESS | {len(recipients)} recipients | {status[:150]}\n")
        return log_msg
    
    except Exception as e:
        error_time = datetime.datetime.now(CM_TIMEZONE).strftime('%Y-%m-%d %H:%M:%S')
        error_msg = f"❌ SCHEDULED CM REPORT FAILED [{error_time}]: {str(e)}"
        print(error_msg)
        with open(SCHEDULED_REPORTS_LOG, "a", encoding="utf-8") as log:
            log.write(f"{error_time} | FAILED | {str(e)[:250]}\n")
        return error_msg

def start_scheduled_cm_reports():
    """
    Initialize and start background scheduler for CM reports
    Returns: scheduler instance or None on failure
    """
    try:
        scheduler = BackgroundScheduler(timezone=CM_TIMEZONE)
        
        # Schedule Morning Report (T1)
        T1_name = f"Daily {CM_REPORT_T1_HOUR:02d}:{CM_REPORT_T1_MINUTE:02d} CM Report"
        T1_args = f"{CM_REPORT_T1_HOUR:02d}:{CM_REPORT_T1_MINUTE:02d} Daily Report"
        scheduler.add_job(
            send_scheduled_cm_report,
            CronTrigger(hour=CM_REPORT_T1_HOUR, minute=CM_REPORT_T1_MINUTE, timezone=CM_TIMEZONE),
            id='cm_report_am',
            name=T1_name,
            replace_existing=True,
            kwargs={'report_type': T1_args}
        )
        
        # Schedule Evening Report (T2)
        T2_name = f"Daily {CM_REPORT_T2_HOUR:02d}:{CM_REPORT_T2_MINUTE:02d} CM Report"
        T2_args = f"{CM_REPORT_T2_HOUR:02d}:{CM_REPORT_T2_MINUTE:02d} Daily Report"
        scheduler.add_job(
            send_scheduled_cm_report,
            CronTrigger(hour=CM_REPORT_T2_HOUR, minute=CM_REPORT_T2_MINUTE, timezone=CM_TIMEZONE),
            id='cm_report_pm',
            name=T2_name,
            replace_existing=True,
            kwargs={'report_type': T2_args}
        )
        
        scheduler.start()
        
        # Log next execution times
        jobs = scheduler.get_jobs()
        next_runs = "\n".join([f"  • {job.name}: {job.next_run_time.astimezone(CM_TIMEZONE).strftime('%Y-%m-%d %H:%M:%S %Z')}" 
                              for job in jobs])
        print(f"\n✅ SCHEDULED CM REPORTS ACTIVATED (Africa/Brazzaville Timezone UTC+1)")
        print(f"Next executions:\n{next_runs}")
        print("Reports will continue running while application is active\n")
        
        return scheduler
    
    except Exception as e:
        print(f"⚠️ CM Scheduler initialization failed: {str(e)}")
        return None


# ======================
# CORE FUNCTIONS (ENHANCED WITH STATUS)
# ======================
def generate_next_id():
    """Safely generate next sequential ID from database"""
    try:
        with open(CMLOGS_DB_FNAME, 'r') as f:
            db = json.load(f)
        return max((entry.get('ID_db', 0) for entry in db), default=0) + 1
    except Exception as e:
        print(f"⚠️ ID generation error: {e}. Using timestamp-based ID.")
        return int(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))

def load_recipients(filename):
    """Load valid emails from specified file (skip comments/empty lines)"""
    recipients = []
    try:
        with open(filename, 'r') as f:
            for line in f:
                email = line.strip()
                if email and not email.startswith('#') and '@' in email:
                    recipients.append(email)
        return recipients
    except FileNotFoundError:
        raise FileNotFoundError(f"Recipient file '{filename}' not found. Create it with one email per line.")
    except Exception as e:
        raise Exception(f"Error reading recipients from '{filename}': {str(e)}")

def save_to_database(entry):
    """Append new entry to JSON database"""
    try:
        with open(CMLOGS_DB_FNAME, 'r') as f:
            db = json.load(f)
    except:
        db = []
    db.append(entry)
    with open(CMLOGS_DB_FNAME, 'w') as f:
        json.dump(db, f, indent=2)

def load_all_logs():
    """Load ALL logs for search/edit operations (not truncated)"""
    try:
        with open(CMLOGS_DB_FNAME, 'r') as f:
            return json.load(f)
    except:
        return []

def normalize_db_keys(db):
    """
    Fix trailing spaces in JSON keys/values (critical for cmlogs-db.json compatibility)
    Returns cleaned database copy without modifying original file
    """
    cleaned = []
    for entry in db:
        clean_entry = {}
        for key, value in entry.items():
            # Remove trailing spaces from keys
            clean_key = key.strip()
            # Remove trailing spaces from string values
            if isinstance(value, str):
                clean_value = value.strip()
            elif isinstance(value, list):
                clean_value = [v.strip() if isinstance(v, str) else v for v in value]
            else:
                clean_value = value
            clean_entry[clean_key] = clean_value
        cleaned.append(clean_entry)
    return cleaned

def export_cm_logs_excel():
    """
    Export CM logs to professionally formatted Excel with status highlighting
    Handles malformed JSON keys with trailing spaces defensively
    """
    try:
        # Load and normalize database keys/values
        with open(CMLOGS_DB_FNAME, 'r', encoding='utf-8') as f:
            raw_db = json.load(f)
        db = normalize_db_keys(raw_db)  # CRITICAL FIX FOR YOUR JSON
        
        if not db:
            return None, "❌ No CM logs to export"
        
        # Create DataFrame with ALL fields
        df = pd.DataFrame(db)
        
        # Ensure required columns exist (defense in depth)
        required_cols = ['ID_db', 'TAGNAME', 'DESCRIPTION', 'reported_by', 'timestamp',
                        'attachment_count', 'original_filenames', 'stored_filenames',
                        'status', 'last_edited', 'edited_by']
        for col in required_cols:
            if col not in df.columns:
                df[col] = "" if col not in ['attachment_count'] else 0
        
        # Format timestamps
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce').dt.strftime('%Y-%m-%d %H:%M:%S')
        df['last_edited'] = pd.to_datetime(df['last_edited'], errors='coerce').dt.strftime('%Y-%m-%d %H:%M:%S')
        
        # Create filename
        timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
        filename = f"CM_Logs_Export_{timestamp}.xlsx"
        filepath = os.path.join(tempfile.gettempdir(), filename)
        
        # Write Excel with formatting
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # Header rows
            pd.DataFrame([["CORRECTIVE MAINTENANCE LOG - OFFICIAL RECORD"]]).to_excel(
                writer, sheet_name='CM_Logs', index=False, header=False
            )
            pd.DataFrame([[f"Exported: {dt.now().strftime('%Y-%m-%d %H:%M:%S')} (Africa/Brazzaville)"]]).to_excel(
                writer, sheet_name='CM_Logs', startrow=1, index=False, header=False
            )
            pd.DataFrame([[f"Total Entries: {len(db)} | Status: sent={len(df[df['status']=='sent'])}, ongoing={len(df[df['status']=='ongoing'])}, completed={len(df[df['status']=='completed'])}"]]).to_excel(
                writer, sheet_name='CM_Logs', startrow=2, index=False, header=False
            )
            
            # Column headers
            headers = ['CM ID', 'Tagname', 'Description', 'Reported By', 'Reported At',
                      'Attachments', 'Original Filenames', 'Stored Filenames',
                      'Status', 'Last Edited', 'Edited By']
            pd.DataFrame([headers]).to_excel(
                writer, sheet_name='CM_Logs', startrow=4, index=False, header=False
            )
            
            # Data rows (format ID as CM-XXXXX)
            display_df = df.copy()
            display_df['ID_db'] = display_df['ID_db'].apply(lambda x: f"CM-{int(x):05d}")
            display_df.to_excel(
                writer, sheet_name='CM_Logs', startrow=5, index=False, header=False,
                columns=required_cols
            )
        
        # Apply professional formatting
        wb = openpyxl.load_workbook(filepath)
        ws = wb.active
        
        # Header styling (rows 1-5)
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF", size=11)
        for row in ws.iter_rows(min_row=1, max_row=5):
            for cell in row:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        
        # Column widths
        col_widths = [12, 18, 40, 20, 20, 12, 30, 30, 12, 20, 20]
        for i, width in enumerate(col_widths, 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = width
        
        # Status highlighting (column I = 9)
        for row_idx in range(6, len(db) + 6):
            status_cell = ws.cell(row=row_idx, column=9)
            status = str(status_cell.value).lower().strip()
            if status == 'sent':
                status_cell.fill = PatternFill(start_color="FFF3E0", end_color="FFF3E0", fill_type="solid")
            elif status == 'ongoing':
                status_cell.fill = PatternFill(start_color="FFF9C4", end_color="FFF9C4", fill_type="solid")
            elif status == 'completed':
                status_cell.fill = PatternFill(start_color="E8F5E9", end_color="E8F5E9", fill_type="solid")
            status_cell.font = Font(bold=True)
            status_cell.alignment = Alignment(horizontal='center')
        
        wb.save(filepath)
        return filepath, f"✅ Exported {len(db)} CM logs to Excel"
    
    except Exception as e:
        return None, f"❌ CM Excel export failed: {str(e)}"

def load_logs_for_display(search_query=None):
    """
    Load logs with optional search filtering including status field
    search_query: string to search across all fields including status
    """
    try:
        with open(CMLOGS_DB_FNAME, 'r') as f:
            db = json.load(f)
        
        # Apply search filter if query exists
        if search_query and search_query.strip():
            query = search_query.lower().strip()
            filtered = []
            for entry in db:
                # Search across ALL fields including status (with safe defaults)
                search_text = " ".join([
                    f"CM-{entry.get('ID_db', 0):05d}",
                    entry.get('TAGNAME', ''),
                    entry.get('DESCRIPTION', ''),
                    entry.get('reported_by', ''),
                    entry.get('status', 'sent'),  # INCLUDE STATUS IN SEARCH
                    str(entry.get('ID_db', ''))
                ]).lower()
                if query in search_text:
                    filtered.append(entry)
            db = filtered
        
        # Sort descending + truncate description
        entries = sorted(db, key=lambda x: x.get('ID_db', 0), reverse=True)[:20]
        return [
            [
                f"CM-{e['ID_db']:05d}",                          # ID
                e.get('TAGNAME', ''),                            # Tagname
                (e.get('DESCRIPTION', '')[:47] + '...') if len(e.get('DESCRIPTION', '')) > 50 else e.get('DESCRIPTION', ''), # Description
                e.get('reported_by', ''),                        # Reported By
                e.get('timestamp', ''),                          # Timestamp
                e.get('attachment_count', 0),                    # Attachments
                e.get('status', 'sent').capitalize(),            # STATUS (NEW COLUMN, capitalized for display)
                "✅" if e.get('last_edited') else ""             # Edited indicator
            ]
            for e in entries
        ]
    except Exception as e:
        print(f"⚠️ Table load error: {e}")
        return []

def update_log_entry(log_id, new_tagname, new_description, new_reported_by, new_status):
    """Update ALL editable fields with validation (status included)"""
    # VALIDATION (critical for data integrity)
    if not new_tagname or not new_tagname.strip():
        return False, "❌ TAGNAME cannot be empty"
    if not new_reported_by or not new_reported_by.strip():
        return False, "❌ 'Reported by' cannot be empty"
    if new_status not in VALID_STATUSES:
        return False, f"❌ Invalid status '{new_status}'. Must be one of: {', '.join(VALID_STATUSES)}"
    
    try:
        with open(CMLOGS_DB_FNAME, 'r') as f:
            db = json.load(f)
        
        for entry in db:
            if entry.get('ID_db') == log_id:
                # Update ALL editable fields (audit trail preserved for core metadata)
                entry['TAGNAME'] = new_tagname.strip()
                entry['DESCRIPTION'] = new_description.strip() if new_description else ""
                entry['reported_by'] = new_reported_by.strip()
                entry['status'] = new_status  # UPDATE STATUS
                entry['last_edited'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                entry['edited_by'] = new_reported_by.strip() if new_reported_by else "System"
                
                with open(CMLOGS_DB_FNAME, 'w') as f:
                    json.dump(db, f, indent=2)
                return True, f"✅ Log CM-{log_id:05d} updated successfully (edited {entry['last_edited']})"
        
        return False, f"❌ Log ID {log_id} not found"
    except Exception as e:
        return False, f"❌ Update failed: {str(e)}"

def delete_log_entry(log_id):
    """Delete log entry from database (attachments require manual cleanup)"""
    try:
        with open(CMLOGS_DB_FNAME, 'r') as f:
            db = json.load(f)
        
        original_count = len(db)
        db = [e for e in db if e.get('ID_db') != log_id]
        
        if len(db) == original_count:
            return False, f"❌ Log ID {log_id} not found"
        
        with open(CMLOGS_DB_FNAME, 'w') as f:
            json.dump(db, f, indent=2)
        
        warning = "⚠️ ATTACHMENTS NOT DELETED (manual cleanup required in attachments/ folder)"
        return True, f"✅ Log CM-{log_id:05d} DELETED from database\n{warning}"
    except Exception as e:
        return False, f"❌ Deletion failed: {str(e)}"

def send_email_with_exports(recipients, attachments_info, custom_note=""):
    """Send email with attachments and custom report note"""
    if not GMAIL_APP_PASSWORD:
        return "❌ EMAIL NOT CONFIGURED: Missing valid GMAIL_APP_PASSWORD in secret.json"
    
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        report_id = custom_note.split('ID: ')[1].split('\n')[0].strip()
        subject = f"🔧 Corrective Maintenance Notice #{report_id} - {timestamp}"
    except:
        subject = f"🔧 Corrective Maintenance Notice - {timestamp}"

    body = f"""CORRECTIVE MAINTENANCE ACTION REQUIRED
========================================
{custom_note}
⚠️ CONFIDENTIAL: Contains operational safety data.
Do not forward outside authorized Congo FLNG personnel.

⚠️ REPLY to this email with the actions taken to fix the issue, to:
- f445_fabio@wison.com
- rocco.demma@eni.com
- michele.firmiani@eni.com
- pessato.alberto_wx@wison.com

========================================
System Details:
• Generated by: NGUYA CM LOG SYSTEM
• Timestamp: {timestamp} (Congo FLNG Time)
• System IP: {MYLOCALIP}
• Attachments: {len(attachments_info)} file(s)

Automated message from CM LOG SYSTEM
"""
    message = MIMEMultipart()
    message['Subject'] = subject
    message['From'] = SENDER_EMAIL
    
    display_recipients = ', '.join(recipients[:3])
    if len(recipients) > 3:
        display_recipients += f" +{len(recipients)-3} others"
    message['To'] = display_recipients
    message.attach(MIMEText(body, 'plain'))

    attached_names = []
    for filepath, orig_name in attachments_info:
        if not os.path.exists(filepath):
            print(f"⚠️ Skipping missing file: {filepath}")
            continue
            
        try:
            ctype, _ = mimetypes.guess_type(filepath)
            if ctype is None:
                ctype = 'application/octet-stream'
            maintype, subtype = ctype.split('/', 1)
            
            with open(filepath, 'rb') as fp:
                part = MIMEBase(maintype, subtype)
                part.set_payload(fp.read())
            encoders.encode_base64(part)
            part.add_header(
                'Content-Disposition',
                f'attachment; filename="{orig_name}"'
            )
            message.attach(part)
            attached_names.append(orig_name)
        except Exception as e:
            print(f"⚠️ Attachment error ({orig_name}): {str(e)}")

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465, timeout=30) as server:
            server.login(SENDER_EMAIL, GMAIL_APP_PASSWORD)
            server.send_message(message, to_addrs=recipients)
        return f"✅ Email sent to {len(recipients)} recipient(s)! Attached: {', '.join(attached_names) if attached_names else 'None'}"
    except smtplib.SMTPAuthenticationError:
        return "❌ EMAIL AUTH FAILED: Invalid GMAIL_APP_PASSWORD. Contact administrator."
    except Exception as e:
        return f"❌ Email failed: {str(e)[:150]}"

def _submit_form_core(uploaded_files, tagname, description, reported_by, recipient_file):
    """Unified handler: validate → save → email (with status='sent' default)"""
    # VALIDATION
    errors = []
    if not tagname or not tagname.strip():
        errors.append("• TAGNAME is mandatory")
    if not reported_by or not reported_by.strip():
        errors.append("• 'Reported by' is mandatory")
    if uploaded_files and len(uploaded_files) > 10:
        errors.append("• Maximum 10 files allowed")
    if errors:
        return "❌ CORRECTION REQUIRED:\n" + "\n".join(errors)
    
    # PROCESS FILES
    attachments_info = []
    stored_filenames = []
    if uploaded_files:
        for temp_path in uploaded_files:
            orig_name = os.path.basename(temp_path)
            safe_name = re.sub(r'[^\w\-_\.]', '_', orig_name)
            storage_name = f"{uuid.uuid4().hex}_{safe_name}"
            dest_path = os.path.join(ATTACHMENTS_DIR, storage_name)
            
            try:
                shutil.copy(temp_path, dest_path)
                attachments_info.append((dest_path, orig_name))
                stored_filenames.append(storage_name)
            except Exception as e:
                return f"❌ File save error ({orig_name}): {str(e)}"

    # GENERATE ID & SAVE TO DB (WITH STATUS='sent')
    next_id = generate_next_id()
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    db_entry = {
        "ID_db": next_id,
        "TAGNAME": tagname.strip(),
        "DESCRIPTION": description.strip() if description else "",
        "reported_by": reported_by.strip(),
        "timestamp": timestamp,
        "attachment_count": len(attachments_info),
        "original_filenames": [orig for _, orig in attachments_info],
        "stored_filenames": stored_filenames,
        "status": "sent",  # ✅ DEFAULT STATUS FOR NEW ENTRIES
        "last_edited": None,
        "edited_by": None
    }

    try:
        save_to_database(db_entry)
    except Exception as e:
        return f"❌ Database save failed: {str(e)}"

    # GENERATE EMAIL NOTE
    custom_note = f"""ID: CM-{next_id:05d}
TAGNAME: {tagname.strip()}
DESCRIPTION: {description.strip() if description else 'None provided'}
Reported by: {reported_by.strip()}
Timestamp: {timestamp}
Status: sent
Attachments: {len(attachments_info)} file(s)
========================================

⚠️ REPLY to this email with the actions taken to fix the issue, to:
- f445_fabio@wison.com
- rocco.demma@eni.com
- michele.firmiani@eni.com
- pessato.alberto_wx@wison.com

========================================
"""
    if attachments_info:
        custom_note += "\n\nAttached Files:\n" + "\n".join(f"• {orig}" for _, orig in attachments_info)
    
    # SEND EMAIL
    try:
        recipients = load_recipients(recipient_file)
        if not recipients:
            return f"⚠️ Report saved (ID: **CM-{next_id:05d}**), but NO RECIPIENTS FOUND in {recipient_file}. Email not sent."
    except Exception as e:
        return f"⚠️ Report saved (ID: **CM-{next_id:05d}**), recipient file error ({recipient_file}): {str(e)}"

    email_result = send_email_with_exports(recipients, attachments_info, custom_note)

    # SUCCESS MESSAGE
    if email_result.startswith("✅"):
        return f"""✅ **SUCCESS!**  
Report saved with ID: CM-{next_id:05d}  
Status: **sent**  
{email_result}  
📁 Files archived in `{ATTACHMENTS_DIR}`"""
    else:
        return f"""⚠️ PARTIAL SUCCESS  
Report saved with ID: CM-{next_id:05d}  
Status: **sent**  
📧 Email status: {email_result} (Data safely stored locally)"""

def submit_to_inst(uploaded_files, tagname, description, reported_by):
    msg = _submit_form_core(uploaded_files, tagname, description, reported_by, INST_RECIPIENTS_FILE)
    return msg, load_logs_for_display()

def submit_to_icss(uploaded_files, tagname, description, reported_by):
    msg = _submit_form_core(uploaded_files, tagname, description, reported_by, ICSS_RECIPIENTS_FILE)
    return msg, load_logs_for_display()

# ======================
# GRADIO INTERFACE (FULLY ENHANCED)
# ======================
CUSTOM_CSS = """
#success-banner {
    background-color: #ecfdf5;
    border-left: 4px solid #10b981;
    padding: 15px;
    border-radius: 0 8px 8px 0;
    margin: 20px 0;
    font-weight: 500;
}
.footer-note {
    background-color: #f0f9ff;
    padding: 12px;
    border-radius: 6px;
    margin-top: 15px;
    font-size: 0.92em;
    border-left: 3px solid #3b82f6;
}
.edit-indicator {
    color: #dc2626;
    font-weight: bold;
    font-size: 1.1em;
}
.gradio-container { max-width: 950px !important; margin: 0 auto !important; }
.compact-text { font-size: 0.95em; color: #555; margin-top: -8px; }
.required::after {
    content: " *";
    color: #ef4444;
    font-weight: bold;
}
.inst-btn {
    background: linear-gradient(to right, #10b981, #0da271) !important;
    color: white !important;
}
.icss-btn {
    background: linear-gradient(to right, #3b82f6, #2563eb) !important;
    color: white !important;
}
.delete-btn {
    background: linear-gradient(to right, #ef4444, #b91c1c) !important;
    color: white !important;
}
.admin-section {
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 15px;
    margin-top: 20px;
    background-color: #f9fafb;
}
"""

# JavaScript: Confirmation dialogs + SMART ROW HIGHLIGHTING with MutationObserver
JS_CODE = """
(function() {
    // ===== CONFIRMATION DIALOGS (UNCHANGED) =====
    document.body.addEventListener('click', function(e) {
        const instBtn = e.target.closest('.inst-btn');
        const icssBtn = e.target.closest('.icss-btn');
        const deleteBtn = e.target.closest('.delete-btn');
        
        if (instBtn && !confirm("⚠️ CONFIRM SUBMISSION\\n\\nAre you sure you want to submit this report to the INST team?\\nThis will send an email to all INST recipients and cannot be undone.")) {
            e.preventDefault(); e.stopPropagation(); return false;
        }
        if (icssBtn && !confirm("⚠️ CONFIRM SUBMISSION\\n\\nAre you sure you want to submit this report to the ICSS team?\\nThis will send an email to all ICSS recipients and cannot be undone.")) {
            e.preventDefault(); e.stopPropagation(); return false;
        }
        if (deleteBtn && !confirm("⚠️ PERMANENT DELETION\\n\\nAre you absolutely sure you want to delete this log entry?\\nAttachments will NOT be deleted (manual cleanup required in attachments/ folder).")) {
            e.preventDefault(); e.stopPropagation(); return false;
        }
    });
    
    // ===== ENTIRE ROW COLORING (ADAPTED FROM YOUR WORKING CODE) =====
    function applyStatusColors() {
        // Find ALL status cells by text content (YOUR PROVEN METHOD)
        const statusCells = Array.from(document.querySelectorAll('#log-table td, #log-table div'))
            .filter(cell => {
                const text = cell.textContent?.trim().toLowerCase();
                return text === 'sent' || text === 'ongoing' || text === 'completed';
            });
        
        statusCells.forEach(cell => {
            // Determine color and tooltip (UNCHANGED FROM YOUR WORKING CODE)
            const status = cell.textContent.trim().toLowerCase();
            let bgColor = '';
            if (status === 'sent') {
                bgColor = '#fff3e0'; // Light orange
                cell.title = 'Workflow status: Sent (Report submitted)';
            } else if (status === 'ongoing') {
                bgColor = '#fff9c4'; // Yellow
                cell.title = 'Workflow status: Ongoing (Work in progress)';
            } else if (status === 'completed') {
                bgColor = '#e8f5e9'; // Light green
                cell.title = 'Workflow status: Completed (Issue resolved)';
            }
            
            // ✅ CRITICAL FIX: COLOR THE PARENT CONTAINER (ENTIRE ROW)
            // In Gradio's DOM, the direct parent of the cell IS the row container
            if (cell.parentElement) {
                cell.parentElement.style.backgroundColor = bgColor;
                cell.parentElement.style.transition = 'background-color 0.2s';
                // Ensure child cells don't override row color
                cell.parentElement.style.background = bgColor; // Cover all bases
            }
            
            // ✅ ENHANCE STATUS CELL (with transparent bg to show row color)
            cell.style.backgroundColor = 'transparent'; // Critical: let row color show through
            cell.style.fontWeight = 'bold';
            cell.style.textAlign = 'center';
            cell.style.borderRadius = '4px';
            cell.style.padding = '2px 6px';
        });
        
        // Style edit indicators (✅) - preserve your working logic
        document.querySelectorAll('#log-table td, #log-table div').forEach(cell => {
            if (cell.textContent.trim() === '✅') {
                cell.style.color = '#dc2626';
                cell.style.fontWeight = 'bold';
                cell.style.fontSize = '1.2em';
                cell.title = 'Log has been edited';
                cell.style.backgroundColor = 'transparent'; // Show row color underneath
            }
        });
    }
    
    // ===== ROBUST INITIALIZATION (YOUR WORKING METHOD) =====
    function init() {
        applyStatusColors();
        
        // Observe entire document body for table updates (critical for virtualized tables)
        const observer = new MutationObserver(() => {
            if (document.getElementById('log-table')) {
                setTimeout(applyStatusColors, 100);
            }
        });
        
        observer.observe(document.body, { 
            childList: true, 
            subtree: true 
        });
    }
    
    // Start after DOM is fully ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
"""

# Start scheduled reports BEFORE launching UI
cm_scheduler = start_scheduled_cm_reports()

with gr.Blocks(
    title="Corrective Maintenance Log",
    theme=gr.themes.Soft(primary_hue="emerald", secondary_hue="blue"),
    css=CUSTOM_CSS
) as demo:
    
    gr.Markdown(f"""# 🔧 Corrective Maintenance Log System
Submit equipment issues with supporting documentation.  
🌐 Network Access: http://{MYLOCALIP}:7960""")
    gr.Markdown("""⚠️ **Mobile Users**: Tap the upload area → Select "Camera" to capture photos directly  
(Works on Android/iOS - no app install needed)""", elem_classes=["footer-note"])
    
    # ===== ADD NEW ENTRY =====    
    with gr.Row():
        with gr.Column():
            file_upload = gr.File(
                label="📎 Attach Documentation (Photos, PDFs, etc.)",
                file_types=[".pdf", ".png", ".jpg", ".jpeg", ".bmp", ".webp"],
                file_count="multiple",
                type="filepath",
            )
            gr.Markdown("Max 10 files. Mobile: Select 'Camera' to capture new photos")
        
        with gr.Column():
            tagname = gr.Textbox(
                label="TAGNAME",
                info="Equipment tag or location identifier",
                placeholder="e.g., PUMP-205, VALVE-B3",
                elem_classes=["required"]
            )
            reported_by = gr.Textbox(
                label="REPORTED BY",
                info="Your full name and role",
                placeholder="e.g., John Doe, Maintenance Technician",
                elem_classes=["required"]
            )
    with gr.Row():
        description = gr.Textbox(
            label="DESCRIPTION",
            info="Detailed issue description",
            placeholder="Describe the problem, symptoms, safety concerns...",
            lines=3,
            max_lines=6
        )            

    # TWO BUTTONS FOR DEPARTMENTAL ROUTING
    with gr.Row():
        save_btn_inst = gr.Button(
            "🧰 SAVE & SEND to INST", 
            variant="primary", 
            size="lg",
            elem_classes=["inst-btn"]
        )
        save_btn_icss = gr.Button(
            "🎛️ SAVE & SEND to ICSS", 
            variant="secondary", 
            size="lg",
            elem_classes=["icss-btn"]
        )

    output_msg = gr.Markdown("""\n\nSave and send operations displayed here.
Check status after submitting...""", elem_id="success-banner")

    # ===== SEARCH BAR =====
    gr.Markdown("")
    gr.Markdown("---")
    gr.Markdown("")
    with gr.Row():
        search_box = gr.Textbox(
            label="🔍 Search Logs (ID, Tagname, Description, Reported By, Status)",
            placeholder="Type to filter recent logs...",
            info="Searches across all fields including status (sent/ongoing/completed)"
        )

    # ===== LOG HISTORY TABLE (WITH STATUS COLUMN & HIGHLIGHTING) =====
    gr.Markdown("## 📋 Recent Maintenance Logs (Last 20 Entries)")
    log_table = gr.DataFrame(
        value=load_logs_for_display(),
        headers=["ID", "Tagname", "Description", "Reported By", "Timestamp", "Attachments", "Status", "Edited"],  # 8 COLUMNS
        datatype=["str", "str", "str", "str", "str", "number", "str", "str"],
        wrap=True,
        interactive=False,
        elem_classes=["log-table"],
        elem_id="log-table"  # CRITICAL FOR JS TARGETING
    )
    gr.Markdown("---")
    with gr.Row():
        with gr.Column(scale=3):
            gr.Markdown("If list is not updated, click the button here -->")
        with gr.Column(scale=1):
            refresh = gr.Button("🔄 Refresh list", 
            variant="secondary", 
            size="lg",
            ) 

    refresh.click(
        load_logs_for_display,
        outputs=log_table,
    )


    # ===== ADMIN SECTION: FULL EDIT/DELETE =====
    with gr.Accordion("🛠️ Admin Functions: Edit or Delete Existing Logs", open=False, elem_classes=["admin-section"]):
        gr.Markdown("⚠️ **Use with caution**: All fields editable except ID, timestamp, and attachments. Deletion removes database entry (attachments require manual cleanup).")

        with gr.Row():
            # ===== EMAIL TEST BUTTON (ADD INSIDE ADMIN ACCORDION) =====
            gr.Markdown("### 🧪 Email System Test")
        with gr.Row():    
            test_email_btn = gr.Button("📤 SEND TEST SCHEDULED REPORT NOW", variant="secondary", elem_classes=["inst-btn"])
            test_email_result = gr.Textbox(label="Test Result", interactive=False, max_lines=5)

        def trigger_test_report():
            """Manually trigger report logic for immediate testing"""
            # Minimal version that bypasses scheduler for instant testing
            try:
                excel_path, msg = export_cm_logs_excel()
                if not excel_path:
                    return f"❌ Export failed: {msg}"
                
                # Get recipients
                recipients = []
                with open(INST_RECIPIENTS_FILE, 'r', encoding='utf-8') as f:
                    for line in f:
                        email = line.strip()
                        if email and not email.startswith('#') and '@' in email:
                            recipients.append(email)
                
                if not recipients:
                    return "❌ No valid recipients in CMemails.txt"
                
                # Send with minimal note
                status = send_email_with_exports(
                    recipients=recipients,
                    attachments_info=[(excel_path, "CM_LOGS_TEST_EXPORT.xlsx")],
                    custom_note="MANUAL TEST REPORT\nGenerated immediately via UI button\nTotal Entries: {}\nIP: {}".format(
                        len(load_all_logs()), MYLOCALIP
                    )
                )
                
                # Cleanup
                if os.path.exists(excel_path):
                    os.remove(excel_path)
                
                return status
            except Exception as e:
                return f"❌ Test failed: {str(e)}"

        test_email_btn.click(
            trigger_test_report,
            outputs=test_email_result
        )

        gr.Markdown("---")



        with gr.Row():
            all_logs = load_all_logs()
            log_ids = [f"CM-{entry['ID_db']:05d}" for entry in sorted(all_logs, key=lambda x: x['ID_db'], reverse=True)] if all_logs else ["No logs available"]
            with gr.Column(scale=2):
                log_selector = gr.Dropdown(
                    choices=log_ids,
                    label="Select Log ID to Edit/Delete",
                    info="Choose a log entry from the database"
                )
            with gr.Column(scale=1):
                load_log_btn = gr.Button("📲 Load Log Details", variant="primary")
                refresh_log_btn = gr.Button("🔄 Refresh the log list", variant="secondary")
            
            def refresh_alllogs():
                all_logs = load_all_logs()
                log_ids = [f"CM-{entry['ID_db']:05d}" for entry in sorted(all_logs, key=lambda x: x['ID_db'], reverse=True)] if all_logs else ["No logs available"]  
                log_selector_new = gr.Dropdown(
                    choices=log_ids,
                    label="Select Log ID to Edit/Delete",
                    info="Choose a log entry from the database"
                )              
                return log_selector_new
            
            refresh_log_btn.click(
                refresh_alllogs,
                outputs=log_selector
            )

        # TWO-COLUMN LAYOUT FOR ALL EDITABLE FIELDS
        with gr.Row():
            with gr.Column():
                edit_tagname = gr.Textbox(
                    label="🏷️ Tagname",
                    info="Equipment tag or location identifier",
                    interactive=False
                )
                edit_description = gr.Textbox(
                    label="📝 Description",
                    lines=3,
                    max_lines=6,
                    interactive=False
                )
            with gr.Column():
                edit_status = gr.Dropdown(
                    choices=VALID_STATUSES,
                    value="sent",
                    label="🚦 Status",
                    info="Workflow progress status",
                    interactive=False
                )
                edit_reported_by = gr.Textbox(
                    label="👤 Reported By",
                    interactive=False
                )
        
        with gr.Row():
            update_btn = gr.Button("💾 UPDATE Log (All Fields)", variant="primary", interactive=False)
            delete_btn = gr.Button(
                "🗑️ DELETE Log Entry", 
                variant="stop", 
                interactive=False,
                elem_classes=["delete-btn"]
            )
        
        admin_output = gr.Markdown("")
        
        # ===== EDIT/DELETE LOGIC =====
        def load_log_details(selected_id):
            if not selected_id or selected_id == "No logs available":
                return (
                    gr.update(interactive=False), gr.update(interactive=False),
                    gr.update(interactive=False), gr.update(interactive=False),
                    gr.update(interactive=False), gr.update(interactive=False), ""
                )
            
            try:
                log_id = int(selected_id.split('-')[1])
                all_logs = load_all_logs()
                for log in all_logs:
                    if log.get('ID_db') == log_id:
                        # Safe status retrieval with fallback
                        current_status = log.get('status', 'sent')
                        if current_status not in VALID_STATUSES:
                            current_status = 'sent'
                        
                        return (
                            gr.update(value=log.get('TAGNAME', ''), interactive=True),
                            gr.update(value=log.get('DESCRIPTION', ''), interactive=True),
                            gr.update(value=current_status, interactive=True),
                            gr.update(value=log.get('reported_by', ''), interactive=True),
                            gr.update(interactive=True),  # update_btn
                            gr.update(interactive=True),  # delete_btn
                            f"✅ Loaded log CM-{log_id:05d}. Edit fields below and click UPDATE."
                        )
                return (
                    gr.update(), gr.update(), gr.update(), gr.update(),
                    gr.update(interactive=False), gr.update(interactive=False),
                    "❌ Log not found"
                )
            except Exception as e:
                return (
                    gr.update(), gr.update(), gr.update(), gr.update(),
                    gr.update(interactive=False), gr.update(interactive=False),
                    f"❌ Error: {str(e)}"
                )
        
        def handle_update(selected_id, new_tagname, new_description, new_status, new_reported_by):
            if not selected_id:
                return "❌ No log selected"
            try:
                log_id = int(selected_id.split('-')[1])
                success, msg = update_log_entry(log_id, new_tagname, new_description, new_reported_by, new_status)
                return msg
            except Exception as e:
                return f"❌ Update error: {str(e)}"

        def handle_delete(selected_id):
            if not selected_id:
                return "❌ No log selected"
            try:
                log_id = int(selected_id.split('-')[1])
                success, msg = delete_log_entry(log_id)
                return msg
            except Exception as e:
                return f"❌ Deletion error: {str(e)}"

        # LOAD LOG DETAILS
        load_log_btn.click(
            load_log_details,
            inputs=[log_selector],
            outputs=[
                edit_tagname, edit_description, 
                edit_status, edit_reported_by,
                update_btn, delete_btn,
                admin_output
            ]
        )

        # UPDATE LOG
        update_btn.click(
            handle_update,
            inputs=[log_selector, edit_tagname, edit_description, edit_status, edit_reported_by],
            outputs=[admin_output]
        ).then(
            lambda: load_logs_for_display(),
            outputs=[log_table]
        )

        # DELETE LOG (with form reset)
        delete_btn.click(
            handle_delete,
            inputs=[log_selector],
            outputs=[admin_output]
        ).then(
            lambda: load_logs_for_display(),
            outputs=[log_table]
        ).then(
            lambda: (
                gr.update(value=None), gr.update(value=""), gr.update(value=""), 
                gr.update(value="sent"), gr.update(value=""),
                gr.update(interactive=False), gr.update(interactive=False), ""
            ),
            outputs=[
                log_selector, edit_tagname, edit_description,
                edit_status, edit_reported_by,
                update_btn, delete_btn, admin_output
            ]
        )

    # ===== SYSTEM INFO =====
    accordionTEXT = f"""📁 Storage: Attachments saved to `{ATTACHMENTS_DIR}` | Database: `{CMLOGS_DB_FNAME}`<br>
🔒 Security: All data remains on your local network. Emails require configured Gmail App Password.<br>
💡 Tip: ID format = CM-XXXXX (auto-generated after submission)<br>
📤 Routing: INST button uses `{INST_RECIPIENTS_FILE}` | ICSS button uses `{ICSS_RECIPIENTS_FILE}`<br>
✏️ Edit Policy: All fields editable except ID, timestamp, and attachments (preserves audit trail)<br>
🚦 Status Workflow: `sent` → `ongoing` → `completed` (manually updated via Admin Functions)<br>
🗑️ Delete Note: Database entry removed only; attachments require manual cleanup in `{ATTACHMENTS_DIR}`"""

    gr.Markdown("---")
    with gr.Accordion("📚 Read Brief Manual", open=False):
        gr.Markdown(accordionTEXT, elem_classes=["footer-note"])    

    # FOOTER (URL FIXED)
    with gr.Row():
        with gr.Column(scale=1):
            try:
                gr.Image("logo.png", height=40, container=False, buttons=[])
            except:
                gr.Markdown("NGUYA FLNG", elem_classes=["footer-note"])
        with gr.Column(scale=2):
            # FIXED URL: Removed trailing spaces
            gr.Markdown(f"""**All rights reserved (C)**  
created by fabio.matricardi@key-solution.eu for NGUYA FLNG Project  
visit [Key Solution SRL](https://key-solution.eu) | Network IP: {MYLOCALIP}""")

    # ===== EVENT HANDLERS =====
    search_box.change(
        load_logs_for_display,
        inputs=[search_box],
        outputs=[log_table]
    )

    save_btn_inst.click(
        submit_to_inst,
        inputs=[file_upload, tagname, description, reported_by],
        outputs=[output_msg, log_table],
        show_progress="full"
    )
    save_btn_icss.click(
        submit_to_icss,
        inputs=[file_upload, tagname, description, reported_by],
        outputs=[output_msg, log_table],
        show_progress="full"
    )
    # ✅ CRITICAL FIX: Auto-refresh table ON PAGE LOAD (MUST BE INSIDE BLOCKS CONTEXT)
    demo.load(load_logs_for_display, outputs=log_table)

# ======================
# LAUNCH
# ======================
if __name__ == "__main__":
    print("\n" + "= "*70)
    print("🚀 CORRECTIVE MAINTENANCE LOG SYSTEM - READY")
    print("= "*70)
    # ... existing print statements ...
    print("\n⏰ SCHEDULED REPORTS:")
    print(f"   • Morning: {CM_REPORT_T1_HOUR:02d}:{CM_REPORT_T1_MINUTE:02d} WAT (Africa/Brazzaville)")
    print(f"   • Evening: {CM_REPORT_T2_HOUR:02d}:{CM_REPORT_T2_MINUTE:02d} WAT (Africa/Brazzaville)")
    print(f"   • Recipients: {INST_RECIPIENTS_FILE}")
    print(f"   • Log file: {SCHEDULED_REPORTS_LOG}")
    print("= "*70 + "\n")

    try:
        demo.launch(server_port=7960, js=JS_CODE,css=CUSTOM_CSS)
    finally:
        # Graceful shutdown of scheduler
        if cm_scheduler and cm_scheduler.running:
            print("\n🛑 Shutting down scheduled CM reports...")
            cm_scheduler.shutdown(wait=False)
            print("✅ CM Scheduler stopped")
