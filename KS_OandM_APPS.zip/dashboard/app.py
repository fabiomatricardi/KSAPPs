# app.py
from flask import Flask, render_template, request, url_for
import json
from pathlib import Path
from datetime import datetime
import threading
import webbrowser

app = Flask(__name__)

# ⚙️ CONFIGURATION: Set to 3, 4, or None for all
DISPLAY_LIMIT = 4  

def load_cards():
    """Load card data from JSON file"""
    json_path = Path(__file__).parent / "cards.json"
    
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            cards = data.get("cards", [])
            
            # 🔧 Convert relative paths to Flask static URLs
            for card in cards:
                if 'image' in card and not card['image'].startswith(('http://', 'https://')):
                    # It's a local image - convert to url_for path
                    card['image_url'] = url_for('static', filename=card['image'])
                else:
                    # It's an external URL - use as-is
                    card['image_url'] = card.get('image', '')
            
            return cards
    except FileNotFoundError:
        print("⚠️  cards.json not found!")
        return []
    except json.JSONDecodeError as e:
        print(f"⚠️  Invalid JSON: {e}")
        return []

@app.route('/')
def home():
    all_cards = load_cards()
    
    # 🎯 Apply limit if configured
    if DISPLAY_LIMIT and DISPLAY_LIMIT > 0:
        cards = all_cards[:DISPLAY_LIMIT]
        total_available = len(all_cards)
    else:
        cards = all_cards
        total_available = len(all_cards)
    
    return render_template(
        'index.html', 
        title="🔑 Key Solution O&M Applications", 
        cards=cards,
        total_available=total_available,
        now=datetime.now()
    )

@app.route('/about')
def about():
    return render_template(
        'index.html', 
        title="About", 
        cards=[], 
        total_available=0,
        about_page=True,
        now=datetime.now()
    )

if __name__ == '__main__':
    url = "http://127.0.0.1:5000"
    threading.Timer(1.25, lambda: webbrowser.open(url) ).start()
    app.run(debug=False, port=5000)