# app.py
from flask import Flask, render_template
import json
from pathlib import Path
from datetime import datetime

app = Flask(__name__)

def load_cards():
    """Load card data from JSON file"""
    json_path = Path(__file__).parent / "cards.json"
    
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("cards", [])
    except FileNotFoundError:
        print("⚠️  cards.json not found! Using fallback data.")
        return []
    except json.JSONDecodeError as e:
        print(f"⚠️  Invalid JSON in cards.json: {e}")
        return []

@app.route('/')
def home():
    cards = load_cards()
    return render_template(
        'index.html', 
        title="🌾 Oat + Flask Demo", 
        cards=cards,
        now=datetime.now()
    )

@app.route('/about')
def about():
    return render_template(
        'index.html', 
        title="About", 
        cards=[], 
        about_page=True,
        now=datetime.now()
    )

@app.route('/reload')
def reload_cards():
    """Debug endpoint to reload cards without restarting server"""
    cards = load_cards()
    return {
        "status": "success",
        "count": len(cards),
        "cards": cards
    }

if __name__ == '__main__':
    app.run(debug=True, port=5000)