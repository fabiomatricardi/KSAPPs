'''
from typing import List
from pydantic import BaseModel, Field
from openai import OpenAI
from datetime import datetime

# for GMAIL function
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import markdown

# FUNCTIONS TO SEND EMAILS
###############################################################################
def convert_markdown_to_html(markdown_text):
    """Converts Markdown to HTML with syntax highlighting and tables."""
    return markdown.markdown(markdown_text, extensions=['extra', 'codehilite'])

def send_markdown_email(
    sender_email, 
    sender_password, 
    receiver_email, 
    subject, 
    markdown_content, 
    smtp_server="smtp.gmail.com", 
    smtp_port=465
):
    """
    Sends a beautifully formatted email using Markdown + HTML.
    Works with Yahoo, Gmail, Outlook — just change the SMTP settings.
    """
    # Convert Markdown to HTML
    html_content = convert_markdown_to_html(markdown_content)
    
    # Create message container
    msg = MIMEMultipart("alternative")
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Subject"] = subject

    # Attach plain text and HTML versions
    part1 = MIMEText(markdown_content, "plain")  # Fallback
    part2 = MIMEText(html_content, "html")      # Pretty version
    msg.attach(part1)
    msg.attach(part2)

    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
            #server.starttls()  # Secure connection
            server.login(sender_email, sender_password)
            server.send_message(msg)
            print("✅ Email sent successfully!")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")

'''


'''
# ORIGINAL SHORT CODE
# coding: utf-8
import smtplib
from email.mime.text import MIMEText
sender_email = "fabio.matricardi@gmail.com"
# Use the generated App Password here
app_password = "vgrv oyhe tral kdaq" 
receiver_email = "f445_fabio@wison.com"
subject = "Test Email"
body = "This is a test email sent from Python."
message = MIMEText(body)
message['Subject'] = subject
message['From'] = sender_email
message['To'] = receiver_email
try:
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
        server.login(sender_email, app_password)
        server.sendmail(sender_email, receiver_email, message.as_string())
    print("Email sent successfully!")
except Exception as e:
    print(f"Error sending email: {e}")




---
'''

'''
# coding: utf-8
import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import mimetypes


APPPWD = "vgrv oyhe tral kdaq"
def send_email_with_attachments(
    sender_email,
    receiver_email,
    subject,
    body,
    attachments=None,  # List of file paths: e.g., ["report.pdf", "data.csv"]
    app_password=None
):
    """
    Send an email with optional file attachments.
    
    Args:
        sender_email (str): Sender's email address
        receiver_email (str): Recipient's email address
        subject (str): Email subject
        body (str): Email body text
        attachments (list, optional): List of file paths to attach
        app_password (str): Gmail App Password (16-character)
    
    Returns:
        bool: True if email sent successfully, False otherwise
    """
    # Create multipart message container
    message = MIMEMultipart()
    message['Subject'] = subject
    message['From'] = sender_email
    message['To'] = receiver_email

    # Attach plain text body
    message.attach(MIMEText(body, 'plain'))

    # Attach files if provided
    if attachments:
        for filepath in attachments:
            if not os.path.exists(filepath):
                print(f"Warning: File not found - {filepath}")
                continue
                
            try:
                # Guess MIME type or default to binary
                ctype, encoding = mimetypes.guess_type(filepath)
                if ctype is None or encoding is not None:
                    ctype = 'application/octet-stream'
                maintype, subtype = ctype.split('/', 1)

                # Read file content
                with open(filepath, 'rb') as fp:
                    part = MIMEBase(maintype, subtype)
                    part.set_payload(fp.read())
                
                # Encode payload in base64
                encoders.encode_base64(part)
                
                # Set filename header (handles UTF-8 filenames properly)
                filename = os.path.basename(filepath)
                part.add_header(
                    'Content-Disposition',
                    'attachment',
                    filename=filename
                )
                message.attach(part)
                print(f"Attached: {filename}")
                
            except Exception as e:
                print(f"Error attaching {filepath}: {e}")
                continue

    # Send email
    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, app_password)
            server.send_message(message)  # Modern method (Python 3.2+)
        print("✓ Email sent successfully!")
        return True
    except Exception as e:
        print(f"✗ Error sending email: {e}")
        return False

# ======================
# Usage Example
# ======================
if __name__ == "__main__":
    # SECURITY NOTE: Never hardcode passwords in production!
    # Use environment variables instead:
    #   import os
    #   app_password = os.environ.get("GMAIL_APP_PASSWORD")
    
    sender_email = "fabio.matricardi@gmail.com"
    app_password = APPPWD  # REPLACE WITH REAL APP PASSWORD
    receiver_email = "f445_fabio@wison.com"
    subject = "Test Email with Attachments"
    body = "This is a test email with 2 attachments sent from Python."
    
    # Specify files to attach (use absolute paths if needed)
    attachments = [
        "FGS_import_template.xlsx",   # First attachment
        "ENIcongo.jpg"      # Second attachment
    ]
    
    send_email_with_attachments(
        sender_email=sender_email,
        receiver_email=receiver_email,
        subject=subject,
        body=body,
        attachments=attachments,
        app_password=app_password
    )


    ---
'''

# coding: utf-8
import smtplib
import os
import re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import mimetypes

APPPWD = "vgrv oyhe tral kdaq"

def read_emails_from_file(filepath):
    """
    Read valid email addresses from a text file (one per line).
    Skips empty lines, comments (#), and invalid formats.
    
    Args:
        filepath (str): Path to email list file
    
    Returns:
        list: Cleaned list of valid email addresses
    """
    emails = []
    email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                email = line.strip()
                # Skip comments and empty lines
                if not email or email.startswith('#'):
                    continue
                # Validate format
                if email_pattern.match(email):
                    emails.append(email)
                else:
                    print(f"⚠️  Warning (line {line_num}): Invalid email skipped: {email}")
        if not emails:
            print(f"❌ No valid emails found in '{filepath}'")
        return emails
    except FileNotFoundError:
        print(f"❌ File not found: '{filepath}'")
        return []
    except Exception as e:
        print(f"❌ Error reading email file: {e}")
        return []

def send_email_with_attachments(
    sender_email,
    recipients,  # Accepts string OR list of strings
    subject,
    body,
    attachments=None,
    app_password=None,
    use_bcc=False  # Optional: hide recipient list from others
):
    """
    Send email to multiple recipients with attachments.
    
    Args:
        sender_email (str): Sender address
        recipients (str or list): Recipient(s) email address(es)
        subject (str): Email subject
        body (str): Email body
        attachments (list, optional): File paths to attach
        app_password (str): Gmail App Password
        use_bcc (bool): If True, recipients are hidden (BCC); else visible (To)
    
    Returns:
        bool: True if sent successfully
    """
    # Normalize recipients to list
    if isinstance(recipients, str):
        recipients = [recipients.strip()]
    elif not isinstance(recipients, list):
        raise ValueError("recipients must be a string or list of strings")
    
    # Clean and validate
    recipients = [r.strip() for r in recipients if r.strip()]
    if not recipients:
        raise ValueError("At least one valid recipient email is required")
    
    # Create message
    message = MIMEMultipart()
    message['Subject'] = subject
    message['From'] = sender_email
    
    # Handle visibility: To vs BCC
    if use_bcc:
        message['To'] = sender_email  # Required header, but recipients hidden
        # BCC recipients handled only in envelope (not in headers)
        envelope_recipients = recipients
    else:
        message['To'] = ', '.join(recipients)  # Visible to all
        envelope_recipients = recipients
    
    message.attach(MIMEText(body, 'plain'))
    
    # Attach files
    if attachments:
        for filepath in attachments:
            if not os.path.exists(filepath):
                print(f"⚠️  Skipped missing file: {filepath}")
                continue
            try:
                ctype, _ = mimetypes.guess_type(filepath)
                if ctype is None:
                    ctype = 'application/octet-stream'
                maintype, subtype = ctype.split('/', 1)
                
                with open(filepath, 'rb') as fp:
                    part = MIMEBase(maintype, subtype)
                    part.set_payload(fp.read())
                encoders.encode_base64(part)
                part.add_header(
                    'Content-Disposition',
                    'attachment',
                    filename=os.path.basename(filepath)
                )
                message.attach(part)
                print(f"📎 Attached: {os.path.basename(filepath)}")
            except Exception as e:
                print(f"❌ Failed to attach {filepath}: {e}")
    
    # Send email
    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, app_password)
            # CRITICAL: Explicitly pass envelope recipients (avoids header parsing issues)
            server.send_message(
                message,
                from_addr=sender_email,
                to_addrs=envelope_recipients
            )
        print(f"✅ Email sent successfully to {len(envelope_recipients)} recipient(s)!")
        if not use_bcc:
            print(f"📬 Visible recipients: {', '.join(envelope_recipients)}")
        return True
    except Exception as e:
        print(f"❌ Email sending failed: {e}")
        return False

# ======================
# USAGE EXAMPLE
# ======================
if __name__ == "__main__":
    # SECURITY: Load password from environment variable (NEVER hardcode!)
    #app_password = os.environ.get("GMAIL_APP_PASSWORD")
    app_password = APPPWD
    if not app_password:
        raise EnvironmentError(
            "❌ GMAIL_APP_PASSWORD not set in environment variables!\n"
            "Set it with: export GMAIL_APP_PASSWORD='xxxx xxxx xxxx xxxx' (Linux/Mac) \n"
            "or set GMAIL_APP_PASSWORD=xxxx... (Windows Command Prompt)"
        )
    
    sender_email = "fabio.matricardi@gmail.com"
    subject = "Monthly Report with Attachments"
    body = (
        "Hello team,\n\n"
        "Please find the attached reports.\n\n"
        "Best regards,\nFabio"
    )
    
    # OPTION 1: Load recipients from file (recommended for bulk)
    recipients = read_emails_from_file('emails.txt')
    
    # OPTION 2: Hardcode recipients (for testing only)
    # recipients = ["user1@wison.com", "user2@wison.com"]
    
    if not recipients:
        print("❌ No valid recipients. Exiting.")
        exit(1)
    
    # Attachments (ensure files exist in working directory)
    attachments = [
        "FGS_import_template.xlsx",   # First attachment
        "ENIcongo.jpg"      # Second attachment
    ]
    
    # Send email (set use_bcc=True to hide recipient list)
    send_email_with_attachments(
        sender_email=sender_email,
        recipients=recipients,
        subject=subject,
        body=body,
        attachments=attachments,
        app_password=APPPWD,
        use_bcc=False  # Change to True for privacy (BCC mode)
    )