import gradio as gr
import json
import os
import datetime
import socket
import tempfile
import re
import shutdown_log, overrides, manual

with gr.Blocks(title="🔒 CCR Master Override-Shutdown Register") as demo:
    overrides.demo.render()
with demo.route("Shutdown Logs"):
    shutdown_log.demo.render()
with demo.route("User Manual"):
    manual.demo.render()


if __name__ == "__main__":
    # Auto-detect LAN IP address
    local_ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.1)
        s.connect(("10.255.255.255", 1))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        try:
            local_ip = socket.gethostbyname(socket.gethostname())
            if local_ip.startswith("127.") or ":" in local_ip:
                local_ip = "YOUR_LOCAL_IP"
        except:
            local_ip = "YOUR_LOCAL_IP"    
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        inbrowser=True,
        )