# 📘 CCR Master Override Register – User Manual  
*For Congo FLNG CCR Operations – Version 1.0*

---

## 📌 Table of Contents
1. [System Overview](#system-overview)  
2. [Access & Login](#access-login)  
3. [User Roles & Permissions](#user-roles-permissions)  
4. [Main Interface Guide](#main-interface-guide)  
   [🔒 Security Enforcement Summary](#security)
5. [Daily Operations Workflow](#daily-operations-workflow)  
6. [📤 Export & Print Functions (All Users)](#export)
7. [Admin Functions](#admin-functions)  
8. [Troubleshooting](#troubleshooting)  
9. [Security & Best Practices](#security-best-practices)  

---

<a id="system-overview"></a>
## 🔒 System Overview

The **CCR Master Override Register** is a secure digital log for tracking all Fire & Gas System (FGS) and ESD overrides in the Central Control Room (CCR). It replaces paper-based logs with:

- ✅ **Real-time visibility** of active overrides across shifts  
- ✅ **Audit trail** with timestamps and operator attribution  
- ✅ **Risk tracking** via Status and Priority fields  
- ✅ **Regulatory compliance** with exportable records (Excel/PDF)  
- ✅ **LAN access** – accessible from any workstation on the facility network  

> ℹ️ **Purpose**: Document all FGS/ESD bypasses per FLNG Safety Procedure. All overrides **must** be logged before implementation.

---
<a id="access-login"></a>
## 🔑 Access & Login

### Network Access
- **From CCR workstations**: Open browser → `http://<CCR-SERVER-IP>:7860`  
  *(Ask Supervisor for current server IP)*
- **From field tablets/laptops**: Same URL (must be on facility Wi-Fi/LAN)

### Login Credentials
| Role | Username | Password | Permissions |
|------|----------|----------|-------------|
| **Operator** | `user` | `user` | View entries, create new overrides |
| **Supervisor** | `manager` | `manager` | View, create, edit, delete entries |
| **Instrument Engineer** | `admin` | `admin` | Full access + Excel import/export |

> ⚠️ **First Login**: Change default passwords via Windows Security → Local Users (contact IT if needed).  
> 🔒 **Security**: Always **log out** when leaving workstation (click 🚪 Logout button).

---

<a id="user-roles-permissions"></a>
## 👥 User Roles & Permissions

| Action | Operator (`user`) | Supervisor (`manager`) | Engineer (`admin`) |
|--------|-------------------|------------------------|--------------------|
| **View all entries** | ✅ | ✅ | ✅ |
| **Create new entry** | ✅ | ✅ | ✅ |
| **Edit existing entry** | ❌ | ✅ | ✅ |
| **Delete entry** | ❌ | ✅ | ✅ |
| **Export to Excel** | ✅ | ✅ | ✅ |
| **Print to PDF (A3)** | ✅ | ✅ | ✅ |
| **Import Excel data** | ❌ | ❌ | ✅ |
| **Access Admin Panel** | ❌ | ❌ | ✅ |

> 💡 **Key Principle**:  
> - **Operators** log new overrides only  
> - **Supervisors** verify/edit entries during shift handover  
> - **Engineers** manage bulk data imports/exports for audits

---

<a id="main-interface-guide"></a>
## 💻 Main Interface Guide

### After Login – Main Register Tab
![Interface Overview](interface-overview.png)  
*(Visual reference: Header with logos → User display → Filter section → Table → Export/Print buttons → Detail form)*

#### 🔍 Filter Section (Top of Page)
Filter entries **without reloading** the page:
1. Type text in any column filter (e.g., `77ATFZP01` in *Module Parameter*)
2. Click **"Apply Filters"**
3. Table updates instantly – only matching entries shown

<a id="security"></a>
### 🔒 Security Enforcement Summary
| Action | `user` Role | `manager` Role | `admin` Role |
|--------|-------------|----------------|--------------|
| **View Approved/Closed** | ✅ Visible | ✅ Visible | ✅ Visible |
| **Edit Approved Field** | ❌ Disabled | ✅ Editable | ✅ Editable |
| **Edit Closed Field** | ❌ Disabled | ✅ Editable | ✅ Editable |
| **Set to YES/NO** | N/A | ✅ Full control | ✅ Full control |
| **Bulk Import Values** | N/A | ✅ Auto-normalized | ✅ Auto-normalized |


> 💡 **Pro Tips**:  
> - Filter `critical` in *Priority* to see high-risk overrides  
> - Filter `OIM` in *Requested By* to see all overrides by specific operator  
> - Clear filters by deleting text → Click "Apply Filters"

#### 📊 Override Entries Table
| Column | Purpose | Example |
|--------|---------|---------|
| **No** | Unique entry number (auto-generated) | `1`, `2`, `69` |
| **Time In** | When override was activated | `2/2/26 14:30` |
| **Module Parameter** | Tag number of bypassed device | `77ATFZP01-301` |
| **Description** | Technical reason for override | `P01 flare vent header GAS detector bypass` |
| **Alarm** | Type of alarm suppressed | `FGS bypass` |
| **Message** | System message | `MOS active` |
| **Priority** | Risk level | `critical` / `high` / `medium` / `low` |
| **Status** | Current state | `awaiting parts` / `risk assessment ongoing` |
| **Date On** | Override start date | `2/2/26` |
| **Requested By** | Operator who requested override | `OIM` |
| **Date Off** | Override removal date (if cleared) | `2/3/26` |
| **Removal Requested By** | Operator who cleared override | `Shift Supervisor` |

#### 📝 Entry Detail Form (Bottom Section)
Used to **create new** or **edit existing** entries:

| Field | Guidance |
|-------|----------|
| **Entry No** | Auto-generated – *never edit* |
| **Time In** | Auto-filled with current time (editable for back-dating) |
| **Module Parameter** | **REQUIRED** – Tag number from P&ID (e.g., `77ATFZP01-301`) |
| **Description** | **REQUIRED** – Full technical reason (e.g., *"GAS detector fault during calibration"*) |
| **Alarm** | Usually `FGS bypass` – leave default unless special case |
| **Message** | Usually `MOS active` – leave default |
| **Priority** | Select risk level per SP-FGS-003:<br>• `critical` = Life safety impact<br>• `high` = Major process impact<br>• `medium` = Minor process impact<br>• `low` = No immediate impact |
| **Status** | Current state:<br>• `active`<br>• `awaiting parts`<br>• `risk assessment ongoing`<br>• `cleared` (when Date Off filled) |
| **Date On** | Auto-filled – editable for historical entries |
| **Requested By** | Auto-filled with your username – *do not change* |
| **Date Off** | Fill ONLY when override is cleared |
| **Removal Requested By** | Fill ONLY when override is cleared |

---

<a id="daily-operations-workflow"></a>
## 🔄 Daily Operations Workflow

### ✅ Creating a New Override Entry (All Users)
1. Click **"➕ Create New Entry"** button (below table)
2. Fill **required fields**:
   - ✅ **Module Parameter** (tag number)
   - ✅ **Description** (technical reason)
   - ✅ **Priority** (risk level)
   - ✅ **Status** (current state)
3. Optional fields:
   - Adjust **Time In**/**Date On** if back-dating
   - Add notes to **Status** field (e.g., *"awaiting vendor support – ticket #INC-789"*)
4. Click **"✅ Create New Entry"**
5. ✅ **Confirmation**: Green status message + entry appears in table

> ⚠️ **Critical Rule**:  
> Overrides **must be logged BEFORE implementation** except in genuine emergencies (log within 15 mins post-activation).

### 🔎 Viewing an Existing Entry
1. Use **filters** to find entry (e.g., by Tag number)
2. Select entry number from **"Select Entry No"** dropdown
3. Click **"Load Selected Entry"**
4. Entry details appear in form below (read-only for Operators)

### ✏️ Editing an Entry (Supervisors/Engineers Only)
1. Load entry as above
2. Edit fields as needed:
   - Update **Status** during shift handover
   - Add **Date Off**/**Removal Requested By** when cleared
   - Correct typos in Description
3. Click **"💾 Save Changes"**
4. ✅ **Confirmation**: Green status message + table refreshes

> ⚠️ **Editing Rules**:  
> - Never change **Entry No**, **Time In**, or **Requested By**  
> - Only update **Status**, **Date Off**, and **Removal Requested By** when clearing overrides  
> - Document reason for edits in **Status** field (e.g., *"Updated per shift handover – John Doe"*)

### 🗑️ Deleting an Entry (Supervisors/Engineers Only)
> ⚠️ **Use with extreme caution** – Deletions are permanent and auditable  
> Only delete:  
> - Duplicate entries  
> - Test entries created during training  
> - Entries created in error **before shift handover**

1. Load entry to delete
2. Click **"🗑️ Delete Entry"**
3. ✅ **Confirmation**: Green status message + entry removed from table

---

<a id="export"></a>
## 📤 Export & Print Functions (All Users)

### 📊 Export FULL Database to Excel
Creates complete backup with timestamp header:

1. Click **"📤 Export FULL Database to Excel"**
2. Wait 2-3 seconds → File downloads automatically
3. Open file → Contains:
   - Title: `FGS MASTER OVERRIDE REGISTER - FULL DATABASE EXPORT`
   - Timestamp of export
   - All entries (including historical cleared overrides)

> 💡 **Use Cases**:  
> - Weekly backups to network drive  
> - Providing data to HSE auditors  
> - Creating trend reports in Excel

### 🖨️ Print CURRENT Table to PDF (A3 Format)
Creates professional printout of **filtered view**:

1. Apply filters if needed (e.g., show only `critical` priority)
2. Click **"🖨️ Print CURRENT Table to PDF"**
3. Wait 3-5 seconds → PDF downloads automatically
4. Print on **A3 paper** (landscape) for posting on CCR board

> 📏 **PDF Specifications**:  
> - Format: A3 Landscape (420 × 297 mm)  
> - Columns optimized for readability:  
>   • Description: 85mm width (fits full technical text)  
>   • Status: 60mm width (shows complete risk notes)  
> - Footer includes: Generation timestamp, user ID, document ID  
> - **CONFIDENTIAL** watermark on all pages  

> 💡 **Use Cases**:  
> - Shift handover boards  
> - Emergency response team briefings  
> - Management daily safety meetings  

---

<a id="admin-functions"></a>
## ⚙️ Admin Functions (Engineers Only)

### 🔐 Accessing Admin Panel
1. Login as `admin`/`admin`
2. **"⚙️ Admin Panel"** tab appears next to "📋 Main Register"
3. Click tab to access import functions

### 📥 Importing Excel Data
> ⚠️ **Critical**: Only import validated data from trusted sources (e.g., backup files). Never import unverified external files.

**Step 1: Prepare Excel File**  
Use **exported files as template** (do NOT create from scratch):
1. Export current database via **"Export FULL Database"** button
2. Open exported `.xlsx` file in Excel
3. **Add new rows at BOTTOM** (after existing data)
4. Fill columns following existing format:
   - Column A: Next available Entry No (check max No in app)
   - Column B: `mm/dd/yy HH:MM` format (e.g., `2/2/26 14:30`)
   - Column C: Tag number (e.g., `77ATFZP01-401`)
   - Column D: Full description
   - ... *(follow existing column patterns)*
5. **SAVE AS NEW FILE** (do not overwrite export)

**Step 2: Import Process**
1. In Admin Panel → Click **"📁 Choose File"**
2. Select your prepared `.xlsx` file
3. Click **"✅ Import Data"**
4. ✅ **Success Message**:  
   `"Import successful! Added X new entries. (Y duplicates skipped.)"`
5. Main table auto-refreshes with new entries

> 🔍 **How Duplicates Are Handled**:  
> - System checks **Entry No** (Column A)  
> - If number exists in database → entry **skipped** (not overwritten)  
> - Only **new** Entry Nos are added  
> - Import report shows count of added vs skipped entries  

> ⚠️ **Never Import**:  
> - Files from unknown sources  
> - Files with macros/VBA  
> - Files with modified Entry Nos that already exist  

---

<a id="troubleshooting"></a>
## 🛠️ Troubleshooting

| Issue | Solution |
|-------|----------|
| **"Site can't be reached" on LAN** | 1. Verify device on same network as server<br>2. Check Windows Firewall → Allow port 7860<br>3. Contact IT for server IP confirmation |
| **Login fails with correct credentials** | 1. Check Caps Lock<br>2. Clear browser cache → Retry<br>3. Restart app server (contact Engineer) |
| **"Invalid credentials" after logout** | Normal behavior – re-enter credentials. Passwords reset to defaults on app restart. |
| **PDF print shows truncated text** | Ensure using **A3 paper** (not A4). PDF is formatted for A3 landscape only. |
| **Import fails with "no valid entries"** | File missing 13 title rows. Use exported file as template (see Admin section). |
| **Export file won't open in Excel** | 1. Ensure file extension is `.xlsx`<br>2. Right-click → "Open with" → Excel<br>3. If corrupted, re-export |
| **Table shows old data after edit** | Click **"Apply Filters"** with empty filters to refresh view |

> 📞 **Support Contact**:  
> - IT Helpdesk: Ext. 4357 (HELP)  
> - Instrument Engineer: Ext. 2281  
> - HSE Advisor: Ext. 2245  

---

<a id="security-best-practices"></a>
## 🔒 Security & Best Practices

### ✅ DO
- [ ] Log overrides **before** implementation (except genuine emergencies)
- [ ] Use actual tag numbers from P&IDs in *Module Parameter*
- [ ] Set accurate *Priority* per SP-FGS-003 risk matrix
- [ ] Update *Status* during shift handovers
- [ ] Log override removal immediately when cleared
- [ ] Export database weekly to network drive (`\\FLNG-SERVER\HSE\FGS_Logs`)
- [ ] Print A3 PDF daily for CCR board

### ❌ DON'T
- [ ] Share credentials with other personnel
- [ ] Leave workstation logged in when unattended
- [ ] Delete entries except duplicates/test data
- [ ] Modify *Entry No*, *Time In*, or *Requested By* fields
- [ ] Import unverified Excel files
- [ ] Use app on public/unsecured networks

### 📜 Audit Trail
All actions are logged in SQLite database (`fgs_overrides.db`):
- Entry creation/modification timestamps
- User attribution for all changes
- Full history preserved (no soft deletes)
- Exportable for regulatory audits

> ℹ️ **Regulatory Compliance**:  
> This system meets requirements of:  
> - FLNG Safety Procedure SP-FGS-003  
> - ISO 13702:2015 (Control and mitigation of hydrocarbon fires)  
> - OGP Report 476 (Process safety indicators)  

---

## 📎 Appendix A: Priority Risk Matrix (SP-FGS-003)

| Priority | Criteria | Example |
|----------|----------|---------|
| **critical** | Life safety impact; potential for escalation to major incident | Bypass of ESD critical shutdown valve |
| **high** | Major process impact; potential production loss >4hrs | Bypass of main flare header gas detector |
| **medium** | Minor process impact; localized effect | Bypass of non-critical area gas detector |
| **low** | No immediate safety/process impact; administrative | Bypass for routine calibration with redundant detection |

---

## 📎 Appendix B: Common Module Parameter Formats

| System | Format | Example |
|--------|--------|---------|
| **Gas Detection** | `77ATFZPxx-xxx` | `77ATFZP01-301` (P01 flare header) |
| **Fire Detection** | `77ATFIRxx-xxx` | `77ATFIR02-105` (Turbine enclosure) |
| **ESD Valves** | `77ESDVxx-xxx` | `77ESDV03-201` (Export line ESDV) |
| **Process Alarms** | `77PT/TT/FITxx` | `77PT04-101` (Separator pressure) |

> ℹ️ **Reference**: Always verify tag numbers against latest P&IDs in `\\FLNG-SERVER\P&IDs\FGS`

---

*Document ID: FGS-MANUAL-1.0*  
*Approved by: Congo FLNG HSE Department*  
*Revision Date: February 2026*  
*CONFIDENTIAL – For Congo FLNG Personnel Only*