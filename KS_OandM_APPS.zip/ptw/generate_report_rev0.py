import gradio as gr
import json
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.lib.enums import TA_CENTER, TA_LEFT
import tempfile
import os

def parse_json_file(json_file):
    """Parse the uploaded JSON file"""
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data

def generate_excel(data):
    """Generate Excel file from JSON data"""
    wb = Workbook()
    ws = wb.active
    ws.title = "Risk Assessment"
    
    # Set up colors
    yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    cyan_fill = PatternFill(start_color="00FFFF", end_color="00FFFF", fill_type="solid")
    red_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
    
    # Define borders
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Header section
    ws.merge_cells(start_row=1, end_row=1, start_column=1, end_column=12)
    ws['A1'] = "Workplace Risk Assessment - Worksheet"
    ws['A1'].font = Font(bold=True, size=16)
    ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
    
    # Site info
    ws['A2'] = "Site/Installation/Area:"
    ws['B2'] = data[0].get('Site', '')
    ws['D2'] = "Prepared By:"
    ws['E2'] = data[0].get('Prepared by', '')
    ws['F2'] = "PTW number:"
    ws['G2'] = data[0].get('PTW', '')
    ws['A3'] = "Description of activity:"
    ws.merge_cells(start_row=3, end_row=3, start_column=2, end_column=3)
    ws['B3'] = data[0].get('Activity_description', '')
    ws['D3'] = "Reviewed By:"
    ws['E3'] = ""
    ws['F3'] = "Date:"
    ws.merge_cells(start_row=3, end_row=3, start_column=6, end_column=12)
    ws['F3'] = data[0].get('Date', '')
    
    # Main table headers
    headers = [
        ['Job Steps', 'Activity', 'HAZARD', '', '', 'INITIAL RISK ANALYSIS', '', '', 'CONTROLS', 'RESIDUAL RISK ANALYSIS', '', ''],
        ['', '', 'Hazard Description', 'Target', 'Consequences', 'Severity', 'Likelihood', 'Risk', 'Controls & Recovery Measures', 'Severity', 'Likelihood', 'Risk']
    ]
    
    # Write headers
    for row_idx, row_data in enumerate(headers, start=5):
        for col_idx, cell_value in enumerate(row_data, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=cell_value)
            cell.font = Font(bold=True, size=9)
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.border = thin_border
    
    # Merge header cells
    ws.merge_cells(start_row=5, end_row=6, start_column=1, end_column=1)  # Job Steps
    ws.merge_cells(start_row=5, end_row=6, start_column=2, end_column=2)  # Activity
    ws.merge_cells(start_row=5, end_row=5, start_column=3, end_column=5)  # HAZARD
    ws.merge_cells(start_row=5, end_row=5, start_column=6, end_column=8)  # INITIAL RISK
    ws.merge_cells(start_row=5, end_row=6, start_column=9, end_column=9)  # CONTROLS
    ws.merge_cells(start_row=5, end_row=5, start_column=10, end_column=12)  # RESIDUAL RISK
    
    # Data rows
    color_map = {
        '#FFFF00': yellow_fill,
        '#00FFFF': cyan_fill,
        '#FF0000': red_fill
    }
    
    row_num = 7
    for idx, task in enumerate(data[1:], start=1):
        ws.cell(row=row_num, column=1, value=idx)
        ws.cell(row=row_num, column=2, value=task.get('Task_description', ''))
        ws.cell(row=row_num, column=3, value=task.get('Hazard_description', ''))
        ws.cell(row=row_num, column=4, value='A/P')
        ws.cell(row=row_num, column=5, value=task.get('Hazard_consequences', ''))
        ws.cell(row=row_num, column=6, value=task.get('Severity', ''))
        ws.cell(row=row_num, column=7, value=task.get('Likelihood', ''))
        
        # Initial risk color
        color1 = task.get('Color', '#FFFF00')
        if color1 in color_map:
            ws.cell(row=row_num, column=8).fill = color_map[color1]
        
        ws.cell(row=row_num, column=9, value=task.get('Additional_control', ''))
        ws.cell(row=row_num, column=10, value=task.get('Severity_2', ''))
        ws.cell(row=row_num, column=11, value=task.get('Likelihood_2', ''))
        
        # Residual risk color
        color2 = task.get('Color_2', '#00FFFF')
        if color2 in color_map:
            ws.cell(row=row_num, column=12).fill = color_map[color2]
        
        # Apply borders and formatting to all cells
        for col in range(1, 13):
            cell = ws.cell(row=row_num, column=col)
            cell.border = thin_border
            cell.alignment = Alignment(wrap_text=True, vertical='top')
        
        row_num += 1
    
    # Adjust column widths
    column_widths = [5, 25, 25, 10, 25, 10, 12, 10, 35, 10, 12, 10]
    for i, width in enumerate(column_widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width
    
    # Save to temp file
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
    wb.save(temp_file.name)
    temp_file.close()
    
    return temp_file.name

def generate_pdf(data):
    """Generate PDF file from JSON data"""
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
    temp_file.close()
    
    doc = SimpleDocTemplate(
        temp_file.name,
        pagesize=landscape(A4),
        rightMargin=0.3*cm,
        leftMargin=0.3*cm,
        topMargin=0.8*cm,
        bottomMargin=0.8*cm
    )
    
    elements = []
    styles = getSampleStyleSheet()
    
    # Custom style for table cells with word wrap
    cell_style = ParagraphStyle(
        'CellStyle',
        parent=styles['Normal'],
        fontSize=6.5,
        leading=8,
        alignment=TA_LEFT,
        wordWrap='CJK'
    )
    
    cell_style_center = ParagraphStyle(
        'CellStyleCenter',
        parent=styles['Normal'],
        fontSize=6.5,
        leading=8,
        alignment=TA_CENTER,
        wordWrap='CJK'
    )
    
    # Header style - slightly larger and bold
    header_style = ParagraphStyle(
        'HeaderStyle',
        parent=styles['Normal'],
        fontSize=7,
        leading=9,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold',
        textColor=colors.whitesmoke
    )
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=14,
        alignment=TA_CENTER,
        spaceAfter=8
    )
    elements.append(Paragraph("Workplace Risk Assessment - Worksheet", title_style))
    
    # Info table with PTW - full width
    info_data = [
        ['Site/Installation/Area:', data[0].get('Site', ''), 'PTW:', data[0].get('PTW', '')],
        ['Description of activity:', data[0].get('Activity_description', ''), 'Prepared By:', data[0].get('Prepared by', '')],
        ['', '', 'Date:', data[0].get('Date', '')]
    ]
    
    info_table = Table(info_data, colWidths=[4.8*cm, 8*cm, 2.2*cm, 5.5*cm])
    info_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
        ('TOPPADDING', (0, 0), (-1, 0), 6),
        ('BACKGROUND', (0, 1), (-1, 2), colors.beige),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ROWSPAN', (1, 0), (1, 2)),
    ]))
    elements.append(info_table)
    elements.append(Spacer(1, 8))
    
    # Main table headers - using Paragraph for proper rendering
    headers = [[
        Paragraph('Job Steps', header_style),
        Paragraph('Activity', header_style),
        Paragraph('Hazard Description', header_style),
        Paragraph('Target', header_style),
        Paragraph('Consequences', header_style),
        Paragraph('Severity', header_style),
        Paragraph('Likelihood', header_style),
        Paragraph('Risk', header_style),
        Paragraph('Controls', header_style),
        Paragraph('Severity', header_style),
        Paragraph('Likelihood', header_style),
        Paragraph('Risk', header_style),
    ]]
    
    # Create main table with Paragraph objects for wrapping columns
    table_data = headers
    
    color_map = {
        '#FFFF00': colors.yellow,
        '#00FFFF': colors.cyan,
        '#FF0000': colors.red
    }
    
    for idx, task in enumerate(data[1:], start=1):
        row = [
            Paragraph(str(idx), cell_style_center),
            Paragraph(task.get('Task_description', ''), cell_style),
            Paragraph(task.get('Hazard_description', ''), cell_style),
            Paragraph('A/P', cell_style_center),
            Paragraph(task.get('Hazard_consequences', ''), cell_style),
            Paragraph(str(task.get('Severity', '')), cell_style_center),
            Paragraph(str(task.get('Likelihood', '')), cell_style_center),
            '',  # Risk color cell
            Paragraph(task.get('Additional_control', ''), cell_style),
            Paragraph(str(task.get('Severity_2', '')), cell_style_center),
            Paragraph(str(task.get('Likelihood_2', '')), cell_style_center),
            ''   # Risk color cell
        ]
        table_data.append(row)
    
    # Column widths optimized for A4 landscape (29.7cm - 0.6cm margins = 29.1cm available)
    # Distributed to maximize space while keeping headers readable
    col_widths = [
        1.6*cm,   # Job Steps
        3.2*cm,   # Activity
        3.2*cm,   # Hazard Description
        1.2*cm,   # Target
        2.9*cm,   # Consequences
        1.6*cm,   # Severity
        1.6*cm,   # Likelihood
        1.2*cm,   # Risk
        4.5*cm,   # Controls (widest)
        1.6*cm,   # Severity
        1.6*cm,   # Likelihood
        1.2*cm,   # Risk
    ]  # Total: ~23.4cm (leaves room for grid lines and padding)
    
    pdf_table = Table(table_data, colWidths=col_widths)
    
    # Table styling
    table_style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 6.5),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 5),
        ('TOPPADDING', (0, 0), (-1, 0), 5),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ROWPADDING', (0, 1), (-1, -1), 2),
    ])
    
    # Add colors for risk cells
    for idx, task in enumerate(data[1:], start=1):
        color1 = task.get('Color', '#FFFF00')
        color2 = task.get('Color_2', '#00FFFF')
        
        if color1 in color_map:
            table_style.add('BACKGROUND', (7, idx), (7, idx), color_map[color1])
        if color2 in color_map:
            table_style.add('BACKGROUND', (11, idx), (11, idx), color_map[color2])
    
    pdf_table.setStyle(table_style)
    elements.append(pdf_table)
    
    # Build PDF
    doc.build(elements)
    
    return temp_file.name

def generate_excel_only(json_file):
    """Generate only Excel file"""
    try:
        data = parse_json_file(json_file)
        excel_path = generate_excel(data)
        return excel_path, "Excel file generated successfully!"
    except Exception as e:
        import traceback
        return None, f"Error: {str(e)}\n{traceback.format_exc()}"

def generate_pdf_only(json_file):
    """Generate only PDF file"""
    try:
        data = parse_json_file(json_file)
        pdf_path = generate_pdf(data)
        return pdf_path, "PDF file generated successfully!"
    except Exception as e:
        import traceback
        return None, f"Error: {str(e)}\n{traceback.format_exc()}"

# Create Gradio interface
with gr.Blocks(title="Workplace Risk Assessment Generator") as demo:
    gr.Markdown("# Workplace Risk Assessment Generator")
    gr.Markdown("Upload a JSON file to generate Excel and PDF risk assessment documents")
    
    with gr.Row():
        with gr.Column():
            json_input = gr.File(
                label="Upload JSON File",
                file_types=[".json"]
            )
            
            with gr.Row():
                excel_btn = gr.Button("Generate Excel", variant="primary")
                pdf_btn = gr.Button("Generate PDF", variant="primary")
            
            status_output = gr.Textbox(label="Status", lines=2)
            
    with gr.Row():
        excel_output = gr.File(label="Download Excel File", visible=True)
        pdf_output = gr.File(label="Download PDF File", visible=True)
    
    excel_btn.click(
        fn=generate_excel_only,
        inputs=[json_input],
        outputs=[excel_output, status_output]
    )
    
    pdf_btn.click(
        fn=generate_pdf_only,
        inputs=[json_input],
        outputs=[pdf_output, status_output]
    )

if __name__ == "__main__":
    demo.launch(server_port=7960,inbrowser=True)