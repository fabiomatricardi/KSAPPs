import gradio as gr
# to save json data
import json
import tempfile
import os
from datetime import datetime
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.lib.enums import TA_CENTER, TA_LEFT
import socket



def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

MYLOCALIP = get_local_ip()

steps_description = [
            "",
            "Step 1 - General Information",
            "Step 2 - Job step 1",
            "Step 3 - Job step 2",
            "Step 4 - Job step 3",
            "Step 5 - Job step 4",
            "Step 6 - Job step 5",
            "Step 7 - Job step 6" 
]

db = []
def get_risk_color(frequency, severity):
    """
    Returns color based on risk matrix coordinates
    frequency: "0", "A", "B", "C", "D", or "E"
    severity: "1", "2", "3", "4", or "5"
    """
    # Define the color zones
    cyan_zone = {
        ("0", "1"), ("0", "2"), ("0", "3"), ("0", "4"), ("0", "5"),
        ("A", "1"), ("A", "2"), ("A", "3"),
        ("B", "1"), ("B", "2"),
        ("C", "1"),
        ("D", "1")
    }

    yellow_zone = {
        ("A", "4"), ("A", "5"),
        ("B", "3"), ("B", "4"),
        ("C", "2"), ("C", "3"),
        ("D", "2"), 
        ("E", "1")
    }

    red_zone = {
        ("B", "5"),
        ("C", "4"), ("C", "5"),
        ("D", "3"),("D", "4"), ("D", "5"),
        ("E", "2"), ("E", "3"), ("E", "4"), ("E", "5")
    }

    coord = (frequency, severity)
    # CREATE NP ARRAYS IMAGES
    import numpy as np

    # Define dimensions
    height = 50
    width = 250

    # Create color arrays (height, width, channels)
    # Cyan: #00FFFF = RGB(0, 255, 255)
    cyan_array = np.full((height, width, 3), (0, 255, 255), dtype=np.uint8)

    # Yellow: #FFFF00 = RGB(255, 255, 0)
    yellow_array = np.full((height, width, 3), (255, 255, 0), dtype=np.uint8)

    # Red: #FF0000 = RGB(255, 0, 0)
    red_array = np.full((height, width, 3), (255, 0, 0), dtype=np.uint8)

    if coord in cyan_zone:
        return cyan_array #"cyan.png" #, "#00FFFF"  # Continuous Improvement
    elif coord in yellow_zone:
        return yellow_array  #"yellow.png" #, "#FFFF00"  # Risk Reduction Measures
    elif coord in red_zone:
        return red_array  #"red.png" #, "#FF0000"  # Intolerable Risk


def get_risk_color_hash(frequency, severity):
    """
    Returns color based on risk matrix coordinates
    frequency: "0", "A", "B", "C", "D", or "E"
    severity: "1", "2", "3", "4", or "5"
    """
    # Define the color zones
    cyan_zone = {
        ("0", "1"), ("0", "2"), ("0", "3"), ("0", "4"), ("0", "5"),
        ("A", "1"), ("A", "2"), ("A", "3"),
        ("B", "1"), ("B", "2"),
        ("C", "1"),
        ("D", "1")
    }
    
    yellow_zone = {
        ("A", "4"), ("A", "5"),
        ("B", "3"), ("B", "4"),
        ("C", "2"), ("C", "3"),
        ("D", "2"), 
        ("E", "1")
    }
    
    red_zone = {
        ("B", "5"),
        ("C", "4"), ("C", "5"),
        ("D", "3"),("D", "4"), ("D", "5"),
        ("E", "2"), ("E", "3"), ("E", "4"), ("E", "5")
    }
    
    coord = (frequency, severity)
    if coord in cyan_zone:
        return "#00FFFF"  #"cyan.png" #, "#00FFFF"  # Continuous Improvement
    elif coord in yellow_zone:
        return "#FFFF00" #"yellow.png" #, "#FFFF00"  # Risk Reduction Measures
    elif coord in red_zone:
        return "#FF0000" #"red.png" #, "#FF0000"  # Intolerable Risk

def download_ptw_json(data):
    """Save JSON data and return file path for both download and input"""
    ptw = data[0].get('PTW', 'unknown_ptw')
    filename = f"{ptw}.json"
    temp_dir = tempfile.gettempdir()
    file_path = os.path.join(temp_dir, filename)
    
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4)
    
    # Return file path for both download and input components
    return file_path, f"✅ {filename} ready for download", file_path


# Define the validation function To enable Button for NExt step only if PTW is not null
def toggle_button_state(text):
    # Check if text exists and is not just whitespace
    if text and text.strip():
        return gr.update(interactive=True)
    else:
        return gr.update(interactive=False)


#----------------------------------------------
#  START OF GRADIO UI
#----------------------------------------------
with gr.Blocks(title="Test steps JSA") as demo:
    # HEADER SECTION
    with gr.Row(elem_classes=["shutdown-header"]):
        with gr.Column(scale=1):
            gr.Image("wisonLOGO.png", height=40, container=False, buttons=[])
            gr.Image("congoFLNG.png", height=30, container=False, buttons=[])
        with gr.Column(scale=2):
            gr.Markdown("# 🚨 Risk Assessment for Offshore Actvities")
            gr.Markdown("### *If you need help, ask HSE for support*")
        with gr.Column(scale=1):
            gr.Image("ENIcongo.jpg", height=40, container=False, buttons=[])
            gr.Image("logo.png", height=30, container=False, buttons=[])
    
    gr.Markdown("---")
    with gr.Row():
        with gr.Column(scale=1):
            actual_steps = gr.Number(precision=1, value=1, 
                label="Actual Step",interactive=False)
        with gr.Column(scale=2):
            actual_steps_description = gr.TextArea(steps_description[int(actual_steps.value)],
                label="Step Description",lines=1, interactive=False)

    general_info = []

    #----------------------------------------------
    #  WALKTRHOUGH STEP 1 - GENERAL INFO
    #----------------------------------------------    
    with gr.Row():
        with gr.Walkthrough(selected=1) as walkthrough1:
            ## STEP 1 General Information
            with gr.Step("Step 1 - General Information", id=1):
                gr.Markdown("### General Information")
                with gr.Row():
                    with gr.Column(scale=1):
                        site = gr.TextArea("NGUYA FLNG", label="Site",lines=1)
                        ptw = gr.TextArea("", label="PTW Number",lines=1,placeholder="Here the PTW number...")
                    with gr.Column(scale=2):
                        prepared_by = gr.TextArea("", label="Prepared by:", lines=1)
                        descriprion_activity = gr.TextArea("", 
                            label="Description of the Activity:", lines=2)
                with gr.Row():
                    with gr.Column(scale=1):
                        date_in = gr.DateTime(include_time=False)
                    with gr.Column(scale=1):    
                        btn_1 = gr.Button("Next - Job step #1", interactive=False, variant="primary")

            #----------------------------------------------
            #  STEP 2 Job step #1
            #----------------------------------------------
            with gr.Step("Step 2 - Job step 1", id=2):
                gr.Markdown("### Job Step # 1")
                #gr.Markdown("*Break the activity down into logical job steps*")
                job_1_descr = gr.Textbox(label="Description of the Step", lines=2,
                    placeholder="Break the activity down into logical job steps")
                hash_color1 = gr.Textbox("",visible=False)
                with gr.Row():
                        job_1_haz_descr_pre = gr.Textbox(label="Hazard Description", lines=3,
                            placeholder="Describe the hazard before additional control measures")
                        job_1_cons_descr_pre = gr.Textbox(label="Conequences", lines=3,
                            placeholder="What could happen, how, to whom")

                with gr.Row():
                    gr.Markdown("""### INITIAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_1_severity_pre = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity",interactive=True,value="0")
                        job_1_lieklyhood_pre = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood",interactive=True)
                    with gr.Column(scale=1):
                            job_1_target = gr.Dropdown(choices=["People", "Environment", "Asset", "Reputation"],
                                max_choices=2,multiselect=True,label="Hazard Target")
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_1_severity_pre,job_1_lieklyhood_pre],every=5)
                gr.Markdown("---")
                with gr.Row():
                    gr.Markdown("""### RESIDUAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                        job_1_add_control_measures = gr.Textbox(label="Control and Recovery Measures", lines=3,
                            placeholder="...required to reduce the Risk")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_1_severity_aft = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity after additional measures",interactive=True,value="0")
                        job_1_lieklyhood_aft = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood after additional measures",interactive=True)
                    with gr.Column(scale=1):
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_1_severity_aft,job_1_lieklyhood_aft],every=5)
                gr.Markdown("---")
                with gr.Row():
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=2):
                        btn_2 = gr.Button("⏩ Next Step")

            #----------------------------------------------
            #  STEP 3 Job step #2
            #----------------------------------------------
            with gr.Step("Job step 2", id=3):
                gr.Markdown("### Job Step # 2")
                #gr.Markdown("*Break the activity down into logical job steps*")
                job_2_descr = gr.Textbox(label="Description of the Step", lines=2,
                    placeholder="Break the activity down into logical job steps")
                hash_color2 = gr.Textbox("",visible=False)
                with gr.Row():
                        job_2_haz_descr_pre = gr.Textbox(label="Hazard Description", lines=3,
                            placeholder="Describe the hazard before additional control measures")
                        job_2_cons_descr_pre = gr.Textbox(label="Conequences", lines=3,
                            placeholder="What could happen, how, to whom")

                with gr.Row():
                    gr.Markdown("""### INITIAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_2_severity_pre = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity",interactive=True,value="0")
                        job_2_lieklyhood_pre = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood",interactive=True)
                    with gr.Column(scale=1):
                            job_2_target = gr.Dropdown(choices=["People", "Environment", "Asset", "Reputation"],
                                max_choices=2,multiselect=True,label="Hazard Target")
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_2_severity_pre,job_2_lieklyhood_pre],every=5)
                gr.Markdown("---")
                with gr.Row():
                    gr.Markdown("""### RESIDUAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                        job_2_add_control_measures = gr.Textbox(label="Control and Recovery Measures", lines=3,
                            placeholder="...required to reduce the Risk")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_2_severity_aft = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity after additional measures",interactive=True,value="0")
                        job_2_lieklyhood_aft = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood after additional measures",interactive=True)   
                    with gr.Column(scale=1):                      
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_2_severity_aft,job_2_lieklyhood_aft],every=5)
                gr.Markdown("---")
                with gr.Row():
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=2):
                        btn_3 = gr.Button("⏩ Next Step")

            #----------------------------------------------
            #  STEP 4 Job step #3
            #----------------------------------------------
            with gr.Step("Job step 3", id=4):
                gr.Markdown("### Job Step # 3")
                job_3_descr = gr.Textbox(label="Description of the Step", lines=2,
                    placeholder="Break the activity down into logical job steps")
                hash_color3 = gr.Textbox("",visible=False)
                with gr.Row():
                        job_3_haz_descr_pre = gr.Textbox(label="Hazard Description", lines=3,
                            placeholder="Describe the hazard before additional control measures")
                        job_3_cons_descr_pre = gr.Textbox(label="Conequences", lines=3,
                            placeholder="What could happen, how, to whom")

                with gr.Row():
                    gr.Markdown("""### INITIAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_3_severity_pre = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity",interactive=True,value="0")
                        job_3_lieklyhood_pre = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood",interactive=True)
                    with gr.Column(scale=1):
                            job_3_target = gr.Dropdown(choices=["People", "Environment", "Asset", "Reputation"],
                                max_choices=2,multiselect=True,label="Hazard Target")
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_3_severity_pre,job_3_lieklyhood_pre],every=5)
                gr.Markdown("---")
                with gr.Row():
                    gr.Markdown("""### RESIDUAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                        job_3_add_control_measures = gr.Textbox(label="Control and Recovery Measures", lines=3,
                            placeholder="...required to reduce the Risk")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_3_severity_aft = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity after additional measures",interactive=True,value="0")
                        job_3_lieklyhood_aft = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood after additional measures",interactive=True)   
                    with gr.Column(scale=1):                      
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_3_severity_aft,job_3_lieklyhood_aft],every=5)
                gr.Markdown("---")
                with gr.Row():
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=2):
                        btn_4 = gr.Button("⏩ Next Step")

            #----------------------------------------------
            #  STEP 5 Job step #4
            #----------------------------------------------
            with gr.Step("Job step 4", id=5):
                gr.Markdown("### Job Step # 4")
                job_4_descr = gr.Textbox(label="Description of the Step", lines=2,
                    placeholder="Break the activity down into logical job steps")
                hash_color4 = gr.Textbox("",visible=False)
                with gr.Row():
                        job_4_haz_descr_pre = gr.Textbox(label="Hazard Description", lines=3,
                            placeholder="Describe the hazard before additional control measures")
                        job_4_cons_descr_pre = gr.Textbox(label="Conequences", lines=3,
                            placeholder="What could happen, how, to whom")

                with gr.Row():
                    gr.Markdown("""### INITIAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_4_severity_pre = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity",interactive=True,value="0")
                        job_4_lieklyhood_pre = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood",interactive=True)
                    with gr.Column(scale=1):
                            job_4_target = gr.Dropdown(choices=["People", "Environment", "Asset", "Reputation"],
                                max_choices=2,multiselect=True,label="Hazard Target")
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_4_severity_pre,job_4_lieklyhood_pre],every=5)
                gr.Markdown("---")
                with gr.Row():
                    gr.Markdown("""### RESIDUAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                        job_4_add_control_measures = gr.Textbox(label="Control and Recovery Measures", lines=3,
                            placeholder="...required to reduce the Risk")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_4_severity_aft = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity after additional measures",interactive=True,value="0")
                        job_4_lieklyhood_aft = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood after additional measures",interactive=True)   
                    with gr.Column(scale=1):                      
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_4_severity_aft,job_4_lieklyhood_aft],every=5)
                gr.Markdown("---")
                with gr.Row():
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=2):
                        btn_5 = gr.Button("⏩ Next Step")

            #----------------------------------------------
            #  STEP 6 Job step #5
            #----------------------------------------------
            with gr.Step("Job step 5", id=6):
                gr.Markdown("### Job Step # 5")
                job_5_descr = gr.Textbox(label="Description of the Step", lines=2,
                    placeholder="Break the activity down into logical job steps")
                hash_color5 = gr.Textbox("",visible=False)
                with gr.Row():
                        job_5_haz_descr_pre = gr.Textbox(label="Hazard Description", lines=3,
                            placeholder="Describe the hazard before additional control measures")
                        job_5_cons_descr_pre = gr.Textbox(label="Conequences", lines=3,
                            placeholder="What could happen, how, to whom")

                with gr.Row():
                    gr.Markdown("""### INITIAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_5_severity_pre = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity",interactive=True,value="0")
                        job_5_lieklyhood_pre = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood",interactive=True)
                    with gr.Column(scale=1):
                            job_5_target = gr.Dropdown(choices=["People", "Environment", "Asset", "Reputation"],
                                max_choices=2,multiselect=True,label="Hazard Target")
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_5_severity_pre,job_5_lieklyhood_pre],every=5)
                gr.Markdown("---")
                with gr.Row():
                    gr.Markdown("""### RESIDUAL RISK ANALYSIS and Calculated Initial Risk *with existing controls in place*""")
                with gr.Row():
                        job_5_add_control_measures = gr.Textbox(label="Control and Recovery Measures", lines=3,
                            placeholder="...required to reduce the Risk")
                with gr.Row():
                    with gr.Column(scale=2):
                        job_5_severity_aft = gr.Dropdown(choices=["0", "A", "B", "C", "D", "E"],
                                max_choices=1,label="Severity after additional measures",interactive=True,value="0")
                        job_5_lieklyhood_aft = gr.Dropdown(choices=["1", "2", "3", "4", "5"],
                                max_choices=1,value="1", label="Likelyhood after additional measures",interactive=True)   
                    with gr.Column(scale=1):                      
                            gr.Image(value=get_risk_color,show_label=False, buttons=[],
                                inputs=[job_5_severity_aft,job_5_lieklyhood_aft],every=5)
                gr.Markdown("---")
                with gr.Row():
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=1):
                        gr.Markdown("")
                    with gr.Column(scale=2):
                        btn_6 = gr.Button("⏩ Next Step")

            #----------------------------------------------
            #  STEP 7 Job step #6 - NO MORE STEPS
            #----------------------------------------------
            with gr.Step("IT IS TIME TO FINALIZE", id=7):
                gr.Markdown("### JOB TOO LONG...")
                gr.Markdown("No more steps here.")
                gr.Markdown("Click on ---> 💾 Download JSON (Named by PTW)")
                gr.Markdown("---")
                gr.Markdown("Exported json file will be ready to be converted in Excel and PDF")
                gr.Markdown("Check Section **Workplace Risk Assessment Generator**")


    #----------------------------------------------
    #  COMMON SECTION TO ALL PARTS
    #----------------------------------------------
    gr.Markdown("---")
    with gr.Row():
        # File component that appears after clicking
        status = gr.Textbox(label="Status", interactive=False)
        file_output = gr.File(label="Download File", visible=False)
        download_btn = gr.DownloadButton(label="💾 Download JSON (Named by PTW)")
    gr.Markdown("---")
    with gr.Row():
        riskmatr_img = gr.Image("riskmatrix.png", buttons=[], height=550)
    gr.Markdown("---")
    
    #----------------------------------------------
    #  SECTION TO EXPORT EXCEL AND PDF
    #----------------------------------------------
    with gr.Row():
        def parse_json_file(json_file):
            """Parse the uploaded JSON file"""
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data

        def generate_excel(data):
            """Generate Excel file from JSON data"""
            wb = Workbook()
            ws = wb.active
            ws.title = "Risk Assessment"
            
            # Set up colors
            yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
            cyan_fill = PatternFill(start_color="00FFFF", end_color="00FFFF", fill_type="solid")
            red_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
            
            # Define borders
            thin_border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            # Header section
            ws.merge_cells(start_row=1, end_row=1, start_column=1, end_column=12)
            ws['A1'] = "Workplace Risk Assessment - Worksheet"
            ws['A1'].font = Font(bold=True, size=16)
            ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
            
            # Site info
            ws['A2'] = "Site/Installation/Area:"
            ws['B2'] = data[0].get('Site', '')
            ws['D2'] = "Prepared By:"
            ws['E2'] = data[0].get('Prepared by', '')
            ws['F2'] = "PTW number:"
            ws['G2'] = data[0].get('PTW', '')
            ws['A3'] = "Description of activity:"
            ws.merge_cells(start_row=3, end_row=3, start_column=2, end_column=3)
            ws['B3'] = data[0].get('Activity_description', '')
            ws['D3'] = "Reviewed By:"
            ws['E3'] = ""
            ws['F3'] = "Date:"
            ws.merge_cells(start_row=3, end_row=3, start_column=6, end_column=12)
            ws['F3'] = data[0].get('Date', '')
            
            # Main table headers
            headers = [
                ['Job Steps', 'Activity', 'HAZARD', '', '', 'INITIAL RISK ANALYSIS', '', '', 'CONTROLS', 'RESIDUAL RISK ANALYSIS', '', ''],
                ['', '', 'Hazard Description', 'Target', 'Consequences', 'Severity', 'Likelihood', 'Risk', 'Controls & Recovery Measures', 'Severity', 'Likelihood', 'Risk']
            ]
            
            # Write headers
            for row_idx, row_data in enumerate(headers, start=5):
                for col_idx, cell_value in enumerate(row_data, start=1):
                    cell = ws.cell(row=row_idx, column=col_idx, value=cell_value)
                    cell.font = Font(bold=True, size=9)
                    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                    cell.border = thin_border
            
            # Merge header cells
            ws.merge_cells(start_row=5, end_row=6, start_column=1, end_column=1)  # Job Steps
            ws.merge_cells(start_row=5, end_row=6, start_column=2, end_column=2)  # Activity
            ws.merge_cells(start_row=5, end_row=5, start_column=3, end_column=5)  # HAZARD
            ws.merge_cells(start_row=5, end_row=5, start_column=6, end_column=8)  # INITIAL RISK
            ws.merge_cells(start_row=5, end_row=6, start_column=9, end_column=9)  # CONTROLS
            ws.merge_cells(start_row=5, end_row=5, start_column=10, end_column=12)  # RESIDUAL RISK
            
            # Data rows
            color_map = {
                '#FFFF00': yellow_fill,
                '#00FFFF': cyan_fill,
                '#FF0000': red_fill
            }
            
            row_num = 7
            for idx, task in enumerate(data[1:], start=1):
                ws.cell(row=row_num, column=1, value=idx)
                ws.cell(row=row_num, column=2, value=task.get('Task_description', ''))
                ws.cell(row=row_num, column=3, value=task.get('Hazard_description', ''))
                ws.cell(row=row_num, column=4, value='A/P')
                ws.cell(row=row_num, column=5, value=task.get('Hazard_consequences', ''))
                ws.cell(row=row_num, column=6, value=task.get('Severity', ''))
                ws.cell(row=row_num, column=7, value=task.get('Likelihood', ''))
                
                # Initial risk color
                color1 = task.get('Color', '#FFFF00')
                if color1 in color_map:
                    ws.cell(row=row_num, column=8).fill = color_map[color1]
                
                ws.cell(row=row_num, column=9, value=task.get('Additional_control', ''))
                ws.cell(row=row_num, column=10, value=task.get('Severity_2', ''))
                ws.cell(row=row_num, column=11, value=task.get('Likelihood_2', ''))
                
                # Residual risk color
                color2 = task.get('Color_2', '#00FFFF')
                if color2 in color_map:
                    ws.cell(row=row_num, column=12).fill = color_map[color2]
                
                # Apply borders and formatting to all cells
                for col in range(1, 13):
                    cell = ws.cell(row=row_num, column=col)
                    cell.border = thin_border
                    cell.alignment = Alignment(wrap_text=True, vertical='top')
                
                row_num += 1
            
            # Adjust column widths
            column_widths = [5, 25, 25, 10, 25, 10, 12, 10, 35, 10, 12, 10]
            for i, width in enumerate(column_widths, start=1):
                ws.column_dimensions[get_column_letter(i)].width = width
            
            # Get PTW number for filename
            ptw_number = data[0].get('PTW', 'Unknown')
            filename = f"RiskAssessment_{ptw_number}.xlsx"
            
            # Save to temp file
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
            wb.save(temp_file.name)
            temp_file.close()
            
            # Rename to include PTW number
            final_path = os.path.join(os.path.dirname(temp_file.name), filename)
            os.rename(temp_file.name, final_path)
            
            return final_path

        def generate_pdf(data):
            """Generate PDF file from JSON data"""
            # Get PTW number for filename
            ptw_number = data[0].get('PTW', 'Unknown')
            temp_pdf = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
            temp_pdf.close()
            
            doc = SimpleDocTemplate(
                temp_pdf.name,
                pagesize=landscape(A4),
                rightMargin=0.3*cm,
                leftMargin=0.3*cm,
                topMargin=0.8*cm,
                bottomMargin=0.8*cm
            )
            
            elements = []
            styles = getSampleStyleSheet()
            
            # Custom style for table cells with word wrap
            cell_style = ParagraphStyle(
                'CellStyle',
                parent=styles['Normal'],
                fontSize=6.5,
                leading=8,
                alignment=TA_LEFT,
                wordWrap='CJK'
            )
            
            cell_style_center = ParagraphStyle(
                'CellStyleCenter',
                parent=styles['Normal'],
                fontSize=6.5,
                leading=8,
                alignment=TA_CENTER,
                wordWrap='CJK'
            )
            
            # Header style - slightly larger and bold
            header_style = ParagraphStyle(
                'HeaderStyle',
                parent=styles['Normal'],
                fontSize=7,
                leading=9,
                alignment=TA_CENTER,
                fontName='Helvetica-Bold',
                textColor=colors.whitesmoke
            )
            
            # Title
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=14,
                alignment=TA_CENTER,
                spaceAfter=8
            )
            elements.append(Paragraph("Workplace Risk Assessment - Worksheet", title_style))
            
            # Info table with PTW - full width
            info_data = [
                ['Site/Installation/Area:', data[0].get('Site', ''), 'PTW:', data[0].get('PTW', '')],
                ['Description of activity:', data[0].get('Activity_description', ''), 'Prepared By:', data[0].get('Prepared by', '')],
                ['', '', 'Date:', data[0].get('Date', '')]
            ]
            
            info_table = Table(info_data, colWidths=[4.8*cm, 8*cm, 2.2*cm, 5.5*cm])
            info_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 7),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
                ('TOPPADDING', (0, 0), (-1, 0), 6),
                ('BACKGROUND', (0, 1), (-1, 2), colors.beige),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('ROWSPAN', (1, 0), (1, 2)),
            ]))
            elements.append(info_table)
            elements.append(Spacer(1, 8))
            
            # Main table headers - using Paragraph for proper rendering
            headers = [[
                Paragraph('Job Steps', header_style),
                Paragraph('Activity', header_style),
                Paragraph('Hazard Description', header_style),
                Paragraph('Target', header_style),
                Paragraph('Consequences', header_style),
                Paragraph('Severity', header_style),
                Paragraph('Likelihood', header_style),
                Paragraph('Risk', header_style),
                Paragraph('Controls', header_style),
                Paragraph('Severity', header_style),
                Paragraph('Likelihood', header_style),
                Paragraph('Risk', header_style),
            ]]
            
            # Create main table with Paragraph objects for wrapping columns
            table_data = headers
            
            color_map = {
                '#FFFF00': colors.yellow,
                '#00FFFF': colors.cyan,
                '#FF0000': colors.red
            }
            
            for idx, task in enumerate(data[1:], start=1):
                row = [
                    Paragraph(str(idx), cell_style_center),
                    Paragraph(task.get('Task_description', ''), cell_style),
                    Paragraph(task.get('Hazard_description', ''), cell_style),
                    Paragraph('A/P', cell_style_center),
                    Paragraph(task.get('Hazard_consequences', ''), cell_style),
                    Paragraph(str(task.get('Severity', '')), cell_style_center),
                    Paragraph(str(task.get('Likelihood', '')), cell_style_center),
                    '',  # Risk color cell
                    Paragraph(task.get('Additional_control', ''), cell_style),
                    Paragraph(str(task.get('Severity_2', '')), cell_style_center),
                    Paragraph(str(task.get('Likelihood_2', '')), cell_style_center),
                    ''   # Risk color cell
                ]
                table_data.append(row)
            
            # Column widths optimized for A4 landscape (29.7cm - 0.6cm margins = 29.1cm available)
            col_widths = [
                1.6*cm,   # Job Steps
                3.2*cm,   # Activity
                3.2*cm,   # Hazard Description
                1.2*cm,   # Target
                2.9*cm,   # Consequences
                1.6*cm,   # Severity
                1.6*cm,   # Likelihood
                1.2*cm,   # Risk
                4.5*cm,   # Controls (widest)
                1.6*cm,   # Severity
                1.6*cm,   # Likelihood
                1.2*cm,   # Risk
            ]
            
            pdf_table = Table(table_data, colWidths=col_widths)
            
            # Table styling
            table_style = TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 6.5),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 5),
                ('TOPPADDING', (0, 0), (-1, 0), 5),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('ROWPADDING', (0, 1), (-1, -1), 2),
            ])
            
            # Add colors for risk cells
            for idx, task in enumerate(data[1:], start=1):
                color1 = task.get('Color', '#FFFF00')
                color2 = task.get('Color_2', '#00FFFF')
                
                if color1 in color_map:
                    table_style.add('BACKGROUND', (7, idx), (7, idx), color_map[color1])
                if color2 in color_map:
                    table_style.add('BACKGROUND', (11, idx), (11, idx), color_map[color2])
            
            pdf_table.setStyle(table_style)
            elements.append(pdf_table)
            
            # Add page break for risk matrix image
            #elements.append(PageBreak())
            
        # Add risk matrix image on second page
            try:
                image_path = 'riskmatrix.png'
                if os.path.exists(image_path):
                    from reportlab.platypus import Image
                    # Use exact available space from the error message with some padding
                    img_width = 810  # Slightly less than 812.88
                    img_height = 535  # Slightly less than 537.92
                    img = Image(image_path, width=img_width, height=img_height)
                    elements.append(Spacer(1, 1*cm))  # Small spacing before image
                    elements.append(img)
            except Exception as e:
                print(f"Warning: Could not add risk matrix image: {e}")
            
            # Build PDF
            doc.build(elements)
            
            # Rename to include PTW number
            filename = f"RiskAssessment_{ptw_number}.pdf"
            final_path = os.path.join(os.path.dirname(temp_pdf.name), filename)
            os.rename(temp_pdf.name, final_path)
            
            return final_path

        def generate_excel_only(json_file):
            """Generate only Excel file"""
            try:
                data = parse_json_file(json_file)
                excel_path = generate_excel(data)
                return excel_path, "Excel file generated successfully!"
            except Exception as e:
                import traceback
                return None, f"Error: {str(e)}\n{traceback.format_exc()}"

        def generate_pdf_only(json_file):
            """Generate only PDF file"""
            try:
                data = parse_json_file(json_file)
                pdf_path = generate_pdf(data)
                return pdf_path, "PDF file generated successfully!"
            except Exception as e:
                import traceback
                return None, f"Error: {str(e)}\n{traceback.format_exc()}"

    # Create Gradio interface
    gr.Markdown("# Workplace Risk Assessment Generator")
    gr.Markdown("Upload a JSON file to generate Excel and PDF risk assessment documents")
    with gr.Row():
        link_status = gr.Markdown("📎 **JSON auto-loaded!** You can now generate Excel/PDF")
        link_status.visible = False       
    with gr.Row():
        with gr.Column():
            json_input = gr.File(
                label="Upload JSON File",
                file_types=[".json"]
            )
            
            with gr.Row():
                excel_btn = gr.Button("Generate Excel", variant="primary")
                pdf_btn = gr.Button("Generate PDF", variant="primary")
            
            status_output = gr.Textbox(label="Status", lines=2)
            
    with gr.Row():
        excel_output = gr.File(label="Download Excel File", visible=True)
        pdf_output = gr.File(label="Download PDF File", visible=True)
 

    excel_btn.click(
        fn=generate_excel_only,
        inputs=[json_input],
        outputs=[excel_output, status_output]
    )
    
    pdf_btn.click(
        fn=generate_pdf_only,
        inputs=[json_input],
        outputs=[pdf_output, status_output]
        )

    with gr.Row(visible=False):
        res = gr.JSON(value=db)

    # FOOTER (URL FIXED)
    with gr.Row():
        with gr.Column(scale=1):
            try:
                gr.Image("logo.png", height=40, container=False, buttons=[])
            except:
                gr.Markdown("NGUYA FLNG", elem_classes=["footer-note"])
        with gr.Column(scale=2):
            # FIXED URL: Removed trailing spaces
            gr.Markdown(f"""**All rights reserved (C)**  
created by fabio.matricardi@key-solution.eu for NGUYA FLNG Project  
visit [Key Solution SRL](https://key-solution.eu) | Network IP: {MYLOCALIP}""")


    def collect_walkthrough1(site, ptw,prepared_by,descriprion_activity, date_in,db):
        formatted_date = datetime.fromtimestamp(date_in).strftime('%d %B %Y')
        data_general = {
        "Site" : site,
        "Prepared by" : prepared_by,
        "PTW" : ptw,
        "Activity_description" : descriprion_activity,
        "Date" : formatted_date
        }
        db = [data_general]
        return db

    def collect_walkthrough2(job_1_descr,job_1_haz_descr_pre,job_1_cons_descr_pre,
        job_1_severity_pre, job_1_lieklyhood_pre,db,job_1_add_control_measures,
        job_1_severity_aft, job_1_lieklyhood_aft):
        hashcolor = get_risk_color_hash(job_1_severity_pre,job_1_lieklyhood_pre)
        hashcolor2 = get_risk_color_hash(job_1_severity_aft,job_1_lieklyhood_aft)
        data_general = {
        "Task_description" : job_1_descr,
        "Hazard_description" : job_1_haz_descr_pre,
        "Hazard_consequences" : job_1_cons_descr_pre,
        "Severity" : job_1_severity_pre,
        "Likelihood" : job_1_lieklyhood_pre,
        "Color" : hashcolor,
        "Additional_control" : job_1_add_control_measures,
        "Severity_2" : job_1_severity_aft,
        "Likelihood_2" : job_1_lieklyhood_aft,
        "Color_2" : hashcolor2,
        }
        print(data_general)
        s =[]
        s.append(db[0])
        s.append(data_general)
        #db = db.append(data_general)
        print(s)
        return gr.update(value=s)

    def collect_walkthrough3(job_2_descr,job_2_haz_descr_pre,job_2_cons_descr_pre,
        job_2_severity_pre, job_2_lieklyhood_pre,db,job_2_add_control_measures,
        job_2_severity_aft, job_2_lieklyhood_aft):
        hashcolor = get_risk_color_hash(job_2_severity_pre,job_2_lieklyhood_pre)
        hashcolor2 = get_risk_color_hash(job_2_severity_aft,job_2_lieklyhood_aft)
        data_general = {
        "Task_description" : job_2_descr,
        "Hazard_description" : job_2_haz_descr_pre,
        "Hazard_consequences" : job_2_cons_descr_pre,
        "Severity" : job_2_severity_pre,
        "Likelihood" : job_2_lieklyhood_pre,
        "Color" : hashcolor,
        "Additional_control" : job_2_add_control_measures,
        "Severity_2" : job_2_severity_aft,
        "Likelihood_2" : job_2_lieklyhood_aft,
        "Color_2" : hashcolor2,
        }
        print(data_general)
        s =[]
        s.append(db[0])
        s.append(db[1])
        s.append(data_general)
        #db = db.append(data_general)
        print(s)
        return gr.update(value=s)

    def collect_walkthrough4(job_3_descr,job_3_haz_descr_pre,job_3_cons_descr_pre,
        job_3_severity_pre, job_3_lieklyhood_pre,db,job_3_add_control_measures,
        job_3_severity_aft, job_3_lieklyhood_aft):
        hashcolor = get_risk_color_hash(job_3_severity_pre,job_3_lieklyhood_pre)
        hashcolor2 = get_risk_color_hash(job_3_severity_aft,job_3_lieklyhood_aft)
        data_general = {
        "Task_description" : job_3_descr,
        "Hazard_description" : job_3_haz_descr_pre,
        "Hazard_consequences" : job_3_cons_descr_pre,
        "Severity" : job_3_severity_pre,
        "Likelihood" : job_3_lieklyhood_pre,
        "Color" : hashcolor,
        "Additional_control" : job_3_add_control_measures,
        "Severity_2" : job_3_severity_aft,
        "Likelihood_2" : job_3_lieklyhood_aft,
        "Color_2" : hashcolor2,
        }
        print(data_general)
        s =[]
        s.append(db[0])
        s.append(db[1])
        s.append(db[2])        
        s.append(data_general)
        #db = db.append(data_general)
        print(s)
        return gr.update(value=s)

    def collect_walkthrough5(job_4_descr,job_4_haz_descr_pre,job_4_cons_descr_pre,
        job_4_severity_pre, job_4_lieklyhood_pre,db,job_4_add_control_measures,
        job_4_severity_aft, job_4_lieklyhood_aft):
        hashcolor = get_risk_color_hash(job_4_severity_pre,job_4_lieklyhood_pre)
        hashcolor2 = get_risk_color_hash(job_4_severity_aft,job_4_lieklyhood_aft)
        data_general = {
        "Task_description" : job_4_descr,
        "Hazard_description" : job_4_haz_descr_pre,
        "Hazard_consequences" : job_4_cons_descr_pre,
        "Severity" : job_4_severity_pre,
        "Likelihood" : job_4_lieklyhood_pre,
        "Color" : hashcolor,
        "Additional_control" : job_4_add_control_measures,
        "Severity_2" : job_4_severity_aft,
        "Likelihood_2" : job_4_lieklyhood_aft,
        "Color_2" : hashcolor2,
        }
        print(data_general)
        s =[]
        s.append(db[0])
        s.append(db[1])
        s.append(db[2]) 
        s.append(db[3])               
        s.append(data_general)
        #db = db.append(data_general)
        print(s)
        return gr.update(value=s)


    def collect_walkthrough6(job_5_descr,job_5_haz_descr_pre,job_5_cons_descr_pre,
        job_5_severity_pre, job_5_lieklyhood_pre,db,job_5_add_control_measures,
        job_5_severity_aft, job_5_lieklyhood_aft):
        hashcolor = get_risk_color_hash(job_5_severity_pre,job_5_lieklyhood_pre)
        hashcolor2 = get_risk_color_hash(job_5_severity_aft,job_5_lieklyhood_aft)
        data_general = {
        "Task_description" : job_5_descr,
        "Hazard_description" : job_5_haz_descr_pre,
        "Hazard_consequences" : job_5_cons_descr_pre,
        "Severity" : job_5_severity_pre,
        "Likelihood" : job_5_lieklyhood_pre,
        "Color" : hashcolor,
        "Additional_control" : job_5_add_control_measures,
        "Severity_2" : job_5_severity_aft,
        "Likelihood_2" : job_5_lieklyhood_aft,
        "Color_2" : hashcolor2,
        }
        print(data_general)
        s =[]
        s.append(db[0])
        s.append(db[1])
        s.append(db[2]) 
        s.append(db[3])   
        s.append(db[4])                     
        s.append(data_general)
        #db = db.append(data_general)
        print(s)
        return gr.update(value=s)

    def update_steps_details(actual_step):
        steps_description = [
            "",
            "Step 1 - General Information",
            "Step 2 - Job step 1",
            "Step 3 - Job step 2",
            "Step 4 - Job step 3",
            "Step 5 - Job step 4",
            "Step 6 - Job step 5",
            "Step 7 - Job step 6"                                    
            ]
        return gr.update(value=actual_step+1,), gr.update(value=steps_description[actual_step+1])

    ptw.change(fn=toggle_button_state, inputs=ptw, outputs=btn_1)

    btn_1.click(fn=collect_walkthrough1,
        inputs=[site,ptw,prepared_by,descriprion_activity, date_in,res],
        outputs=res).then(fn=update_steps_details,
        inputs=actual_steps,
        outputs=[actual_steps,actual_steps_description]).then(
        lambda: gr.Walkthrough(selected=2),outputs=walkthrough1)

    btn_2.click(fn=collect_walkthrough2,
        inputs=[job_1_descr,job_1_haz_descr_pre,job_1_cons_descr_pre,
        job_1_severity_pre, job_1_lieklyhood_pre,res,job_1_add_control_measures,
        job_1_severity_aft, job_1_lieklyhood_aft],
        outputs=res).then(fn=update_steps_details,
        inputs=actual_steps,
        outputs=[actual_steps,actual_steps_description]).then(
        lambda: gr.Walkthrough(selected=3),outputs=walkthrough1)

    btn_3.click(fn=collect_walkthrough3,
        inputs=[job_2_descr,job_2_haz_descr_pre,job_2_cons_descr_pre,
        job_2_severity_pre, job_2_lieklyhood_pre,res,job_2_add_control_measures,
        job_2_severity_aft, job_2_lieklyhood_aft],
        outputs=res).then(fn=update_steps_details,
        inputs=actual_steps,
        outputs=[actual_steps,actual_steps_description]).then(
        lambda: gr.Walkthrough(selected=4),outputs=walkthrough1)

    btn_4.click(fn=collect_walkthrough4,
        inputs=[job_3_descr,job_3_haz_descr_pre,job_3_cons_descr_pre,
        job_3_severity_pre, job_3_lieklyhood_pre,res,job_3_add_control_measures,
        job_3_severity_aft, job_3_lieklyhood_aft],
        outputs=res).then(fn=update_steps_details,
        inputs=actual_steps,
        outputs=[actual_steps,actual_steps_description]).then(
        lambda: gr.Walkthrough(selected=5),outputs=walkthrough1)

    btn_5.click(fn=collect_walkthrough5,
        inputs=[job_4_descr,job_4_haz_descr_pre,job_4_cons_descr_pre,
        job_4_severity_pre, job_4_lieklyhood_pre,res,job_4_add_control_measures,
        job_4_severity_aft, job_4_lieklyhood_aft],
        outputs=res).then(fn=update_steps_details,
        inputs=actual_steps,
        outputs=[actual_steps,actual_steps_description]).then(
        lambda: gr.Walkthrough(selected=6),outputs=walkthrough1)

    btn_6.click(fn=collect_walkthrough6,
        inputs=[job_5_descr,job_5_haz_descr_pre,job_5_cons_descr_pre,
        job_5_severity_pre, job_5_lieklyhood_pre,res,job_5_add_control_measures,
        job_5_severity_aft, job_5_lieklyhood_aft],
        outputs=res).then(fn=update_steps_details,
        inputs=actual_steps,
        outputs=[actual_steps,actual_steps_description]).then(
        lambda: gr.Walkthrough(selected=7),outputs=walkthrough1)

    # Update the download_btn.click to also show this message
    download_btn.click(
        fn=download_ptw_json,
        inputs=res,
        outputs=[file_output, status, json_input]
    ).then(
        fn=lambda: gr.update(visible=True),
        outputs=file_output
    ).then(
        fn=lambda: gr.update(visible=True),
        outputs=link_status
    ).then(
        fn=lambda: gr.update(visible=False),
        outputs=riskmatr_img
    )


if __name__ == "__main__":
    demo.launch(server_port=7760)
